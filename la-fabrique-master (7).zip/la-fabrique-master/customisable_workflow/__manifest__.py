# -*- coding: utf-8 -*-
{
    'name': 'Workflows',
    'version': '16.0.0',
    'category': 'Tools',
    'summary': 'Workflow management',
    'license': 'LGPL-3',
    'depends': [ 'base','mail','report_docx',
    ],
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'views/res_users.xml',
        'views/menu.xml',
        'views/document_type.xml',        
        'views/workflow.xml',
        'views/step.xml',
        'views/step_decision.xml',
        'views/document.xml',
        'views/work_generated_document.xml',
        'views/notification_type.xml',
        'views/transition_rule.xml',
        'views/condition.xml',
        'wizard/justification.xml',
        'report/menu_report.xml'
    ],
    'assets': {
        'web.assets_backend': [
            'customisable_workflow/static/src/**/*',
        ],
    },
    'demo': [],
    'qweb': [],
    'images': [],
    'installable': True,
    'application': False,
    'auto_install': False,
}
