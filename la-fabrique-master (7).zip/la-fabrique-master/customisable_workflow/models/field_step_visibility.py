#-*- coding:utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
import logging
_logger = logging.getLogger(__name__)

class FieldStepVisibility(models.Model):
    _name = 'customisable_workflow.field_step_visibility'
    _description = 'Fields visibility by step'

    field_id = fields.Many2one('ir.model.fields',
                                ondelete='cascade', string="Champ", required=True)
    is_mandatory = fields.Boolean("Est obligatoire?")
    step_id = fields.Many2one("customisable_workflow.step", string="Etape", ondelete="cascade", required=True)
    workflow_id = fields.Many2one("customisable_workflow.workflow", string="Processus", ondelete="cascade", required=True)

    _sql_constraints = [
        ('field_uniq', 'unique(field_id, step_id, workflow_id)', 'Les valeurs des champs étape, processus et champ doivent être uniques.')
    ]

    @api.onchange("workflow_id")
    def onchange_res_model(self):
        for record in self:
            if record.workflow_id:
                domain = [('model_id.model', '=', record.workflow_id.res_model_id.model),('readonly', '=', False),('ttype', '!=', 'many2many'),('ttype', '!=', 'one2many')]
                return {'domain': {'field_id': domain}}
