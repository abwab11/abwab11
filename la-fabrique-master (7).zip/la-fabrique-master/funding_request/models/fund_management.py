# -*- coding:utf-8 -*-
from odoo import models, fields, api, _
import logging

_logger = logging.getLogger(__name__)

class FundingRequest(models.Model):
    _inherit = 'fund_management.demand'
    _description = 'Demande de Financement'
    
    beneficiary_id = fields.Many2one('res.users', string="Bénéficiaire", default=lambda self: self.env.user)
    financial_institution_id = fields.Many2one('fund_management.work_owner', string="Bénéficiaire", compute='_compute_financial_institution_id', store=True)

    @api.depends('beneficiary_id')
    def _compute_financial_institution_id(self):
        for record in self:
            if record.env.user.has_group('fund_management.fund_requester_group'):
                record.financial_institution_id = record.beneficiary_id.work_owner_id
            else:
                record.financial_institution_id = False  # Leave it empty for manual input
