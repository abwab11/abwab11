# -*- coding: utf-8 -*-
{
    'name': 'Demande de financement',
    'version': '1.0',
    'summary': 'Module de demande de financement',
    'category': 'Accounting',
    'author': 'MW',
    'depends': ['base', 'mail', 'fund_management'],
    'data': [
        'security/security.xml',
        'views/menu_views.xml'
    ],
    'assets': {
        'web.assets_backend': [
            'fund_management/static/src/**/*',
        ],
    },
    'demo': [],
    'qweb': [],
    'images': [],
    'installable': True,
    'application': False,
    'auto_install': False,
}
