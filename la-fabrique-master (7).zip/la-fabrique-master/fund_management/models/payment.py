#-*- coding:utf-8 -*-
from odoo import models, fields, api,  _
import logging
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)

class Payment(models.Model):
    _name = 'fund_management.payment'
    _description = 'Payment'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'id desc'
    
    amount = fields.Float(string='Montant', required=True)
    state = fields.Selection([
            ('brouillon', 'Brouillon'),
            ('en_cours', 'En-cours'),
            ('valider', 'Valider'),
            ('annuler', 'Annuler')
        ], string='Statut', default='brouillon') 
    date = fields.Date(string='Date', required=True, default=fields.Date.today())
    loan_id = fields.Many2one('fund_management.payment.schedule', string='Amortissement')  # Fund (shown when operation is transfer)
    remaining_to_pay = fields.Float(string="Reste à payer", related='loan_id.remaining_to_pay')

    # Buttons logic
    def action_soumettre(self):
        # if self.remaining_to_pay < self.amount:
        #     raise ValidationError("Vous ne pouvez pas payer plus que le montant de l'échéance.")
        self.state = 'en_cours'
    
    def action_valider(self):
        # if self.remaining_to_pay < self.amount:
        #     raise ValidationError("Vous ne pouvez pas payer plus que le montant de l'échéance.")
        self.state = 'valider'

    def action_annuler(self):
        self.state = 'annuler'