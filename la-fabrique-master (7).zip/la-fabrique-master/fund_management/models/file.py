#-*- coding:utf-8 -*-
from odoo import models, fields, api,  _
import logging

_logger = logging.getLogger(__name__)

class Dossier(models.Model):
    _name = 'fund_management.file'
    _description = 'Dossier Management'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'id desc'

    fund_id = fields.Many2one('fund_management.funds', string='Fonds', required=True)  # Linked fund
    name = fields.Char(string='Nom du Dossier', required=True)  # Dossier name
    description = fields.Text(string='Description')  # Description of the dossier
    date_creation = fields.Date(string='Date de Création', default=fields.Date.today())  # Creation date
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)