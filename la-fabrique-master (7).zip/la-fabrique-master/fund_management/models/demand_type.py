#-*- coding:utf-8 -*-
from odoo import models, fields, api,  _
import logging

_logger = logging.getLogger(__name__)
class DemandType(models.Model):
    _name = 'fund_management.demand_type'
    _description = 'Type de demande'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'id desc'
    
    name = fields.Char(string='Nom', required=True)
    is_subvention = fields.Boolean(string='Subvention ?')
    is_credit = fields.Boolean(string='Credit ? ')
    mixte = fields.Boolean(string='Mixte ? ')
    fund_ids = fields.Many2many('fund_management.funds', string="Fonds associés")  # Link multiple funds to the demand type
    object_ids = fields.Many2many('fund_management.object', string="Objet de la demande")  # Link multiple funds to the demand type
    workflow_id = fields.Many2one('customisable_workflow.workflow', string='Workflow')
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
    
    def action_primary_channel_button(self):
        self.ensure_one()
        action = self.env['ir.actions.actions']._for_xml_id('fund_management.financial_product_view_kanban')
        return action