from odoo import models, fields, api
from datetime import date
import logging

_logger = logging.getLogger(__name__)
class FundManagementDatAccount(models.Model):
    _name = 'fund_management.dat_account'
    _description = 'DAT Account'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'id desc'

    account_number = fields.Char(string="Numéro de compte", required=True)
    name = fields.Char(string='Code')  # Auto-generated code
    created_date = fields.Date(string="Date de valeur", default=fields.Date.context_today)
    end_date = fields.Date(string="Date d'échéance ", required=True)
    active_days = fields.Integer(string="Nombre de jours actif à date", compute="_compute_active_days",store=True)
    normal_active_days = fields.Integer(string="Nombre de jour normalement actif ", compute="_compute_normal_active_days",store=True)
    inactive_days = fields.Integer(string="Nombre de jours inactif  ", compute="_compute_inactive_days",store=True)
    bank_id = fields.Many2one('res.bank', string="Banque")
    current_balance = fields.Float(string="Solde actuel du compte", compute='_compute_valeur_actuelle',store=True)
    transaction_ids = fields.One2many('fund_management.dat_transaction', 'account_id', string="Transactions")
    incident_ids = fields.One2many('fund_management.dat_incident', 'account_id', string="Incidents")
    
    credit_line_ids = fields.One2many('fund_management.credit_line', 'dat_account_id', string="Garantie sur le DAT")
    
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)

    interest_rate = fields.Float(string="Taux d'intérêt annuel (en %)", digits=[12, 3])  # Variable interest rate
    normal_active_interest = fields.Float(string="Intérêt normalement actif", compute='_compute_normal_active_interest',store=True)
    active_interest_to_date = fields.Float(string="Intérêt actif à date", compute='_compute_active_interest_to_date',store=True)
    balance_after_anniversary = fields.Float(string="Solde du DAT après la date d’anniversaire", compute='_compute_balance_after_anniversary',store=True)
    initial_balance = fields.Float(string="Solde de début")  # Assuming initial balance is defined somewhere
    
    total_guarantee_amount = fields.Float('Montant total de guarantie', compute='_compute_total_guarantee_amount',store=True)
    available_guarantee_amount = fields.Float('Montant disponible pour garantie', compute='_compute_available_guarantee_amount',store=True)
    
    def update_fields(self):
        for record in self:
            record._compute_total_guarantee_amount()
            record._compute_available_guarantee_amount()
    
    @api.depends('total_guarantee_amount', 'current_balance')  
    def _compute_available_guarantee_amount(self):
        for record in self:
            if record.total_guarantee_amount and record.current_balance:
                record.available_guarantee_amount = record.current_balance - record.total_guarantee_amount
            else:
                record.available_guarantee_amount = 0
            
    @api.depends('credit_line_ids')  
    def _compute_total_guarantee_amount(self):
        for record in self:
            if record.credit_line_ids:
                record.total_guarantee_amount = sum((t.garantee_amount) for t in record.credit_line_ids)
            else:
                record.total_guarantee_amount = 0

    @api.depends('end_date', 'created_date')
    def _compute_normal_active_days(self):
        """Calculate the normal active days between creation and end date."""
        for record in self:
            if record.created_date and record.end_date and record.end_date > record.created_date:
                record.normal_active_days = (record.end_date - record.created_date).days
            else:
                record.normal_active_days = 0

    @api.depends('incident_ids')
    def _compute_inactive_days(self):
        """Calculate the total inactive days based on incidents."""
        for account in self:
            if account.incident_ids:
                total_incident_days = sum(incident.number_of_days for incident in account.incident_ids)
                account.inactive_days = max(total_incident_days, 0)
            else:
                account.inactive_days = 0

    @api.depends('created_date')
    def _compute_active_days(self):
        """Calculate active days from creation to today."""
        for account in self:
            if account.created_date:
                account.active_days = (date.today() - account.created_date).days 
            else:
                account.active_days = 0

    @api.depends('transaction_ids.state', 'transaction_ids.amount')
    def _compute_valeur_actuelle(self):
        """Calculate current balance based on validated transactions."""
        for dat in self:
            dat.current_balance = sum(t.amount for t in dat.transaction_ids if t.state == 'valider')

    @api.depends('current_balance', 'interest_rate', 'normal_active_days')
    def _compute_normal_active_interest(self):
        """Calculate normal active interest based on normal active days."""
        for dat in self:
            active_day = dat.normal_active_days/365
            current_balance = dat.initial_balance
            interest = dat.interest_rate / 100
            try:
                dat.normal_active_interest = active_day * current_balance * interest
            except Exception as e:
                dat.normal_active_interest = 0

    @api.depends('current_balance', 'interest_rate', 'active_days')
    def _compute_active_interest_to_date(self):
        """Calculate interest active to date based on current active days."""
        for dat in self:
            dat.active_interest_to_date = dat.current_balance * (dat.interest_rate/100)  *(dat.active_days/365)

    @api.depends('initial_balance', 'interest_rate', 'normal_active_days', 'inactive_days')
    def _compute_balance_after_anniversary(self):
        """Calculate balance after anniversary date considering inactive days."""
        for dat in self:
            adjusted_active_days = dat.normal_active_days - dat.inactive_days
            dat.balance_after_anniversary = dat.initial_balance + (dat.initial_balance * (dat.interest_rate/100) * (adjusted_active_days/365))