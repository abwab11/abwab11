# -*- coding: utf-8 -*-
from odoo import api, fields, models

class Manager(models.Model):
    _name = "fund_management.manager"
    _inherit = 'fund_management.person'
    _description = 'General manager model'

    work_owner_id = fields.Many2one('fund_management.work_owner', string=u'Institution financière')
    job_ids = fields.Many2many('fund_management.job', string='Fonctions', relation='job_manager_rel')
    street = fields.Char('Adresse')
    nationality = fields.Many2one('res.country', string='Nationalité')
    birth_date = fields.Date('Date de naissance')
    birth_place = fields.Char('Lieu de naissance')
    national_id_number = fields.Char("Numéro d'identification national")
    delivery_date = fields.Date('Date de delivrance') 
    marital_status = fields.Selection([('married', "Marié(e)"), ('single', "Célibataire"), ('separated', "Divorcé(e)"), ('widowed', "Veuve")] ,string="Situation matrimoniale")
    marital_regime = fields.Selection([('community_of_property', "Communauté des biens"), ('separation_of_property', "Séparation des biens")] ,string="Régime matrimonial")
    department = fields.Many2one("fund_management.department", string=u"Département")
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)

    def get_value_marital_status(self):
        return dict(self._fields['marital_status'].selection).get(self.marital_status)

    def get_value_marital_regime(self):
        return dict(self._fields['marital_regime'].selection).get(self.marital_regime)

