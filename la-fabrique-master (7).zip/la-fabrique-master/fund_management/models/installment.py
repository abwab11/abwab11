#-*- coding:utf-8 -*-
from odoo import models, fields, api, _
from datetime import date
from dateutil.relativedelta import relativedelta
from odoo.exceptions import ValidationError
import logging
_logger = logging.getLogger(__name__)

class Installment(models.Model):
    _name = 'fund_management.installment'
    
    date = fields.Date(string="Date de mise en place", required=True)
    amount = fields.Integer(string="Montant")
    justificatif = fields.Binary(string='Justificatif') 
    demand_id = fields.Many2one('fund_management.demand', string="Dossier", ondelete="cascade")
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
