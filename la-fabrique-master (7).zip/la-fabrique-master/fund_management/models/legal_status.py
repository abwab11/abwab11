#-*- coding:utf-8 -*-
from odoo import models, fields, api, _

class LegalStatus(models.Model):
    _name = 'fund_management.legal_status'
    _order = "name asc"
    _description = "Forme juridique"
    
    name = fields.Char(string='Forme juridique', required=True)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)