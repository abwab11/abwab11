#-*- coding:utf-8 -*-
from odoo import models, fields, api,  _
import logging
from dateutil.relativedelta import relativedelta
from datetime import date


_logger = logging.getLogger(__name__)

class Beneficiary(models.Model):
    _name = 'fund_management.beneficiary'
    _description = 'Beneficiary Management'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'fund_management.work_owner']
    _order = 'id desc'

    ninea = fields.Char(string='NINEA', required=True)
    capital = fields.Char(string='Capital')
    acronym = fields.Char(string='Abrégé', required=True)
    managing_director_ids = fields.One2many('fund_management.manager', 'work_owner_id', string="Dirigeants")
    bank_id = fields.Many2one('res.bank', string='Banque')
    # company_res_partner_bank_ids = fields.One2many('res.partner.bank', 'bank_id', string="Comptes", related="bank_id.res_partner_bank_ids")
    general_manager_id = fields.Many2one('fund_management.manager', string='Directeur général')
    email = fields.Char(string=u"Email")
    ninea = fields.Char(string='NINEA')
    street = fields.Char(string='Rue')
    street2 = fields.Char(string='Rue 2')
    city = fields.Char(string='Ville')
    state_id = fields.Many2one("res.country.state", string='State', ondelete='restrict', domain="[('country_id', '=?', country_id)]")
    zip = fields.Char(string='ZIP')
    country_id = fields.Many2one('res.country', string='Pays', ondelete='restrict')
    business_sector_id = fields.Many2one("fund_management.business_sector", string=u"Secteur d'activité")
    rccm = fields.Char(string="RCCM")
    manager_gender = fields.Selection([('male', "Homme"), ('female', "Femme")] ,string="Genre du dirigeant", required=True)
    legal_status = fields.Many2one("fund_management.legal_status" ,string="Forme juridique")
    faculty = fields.Many2one("fund_management.faculty" ,string=u"Filière")
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
    
    # born_date = fields.Date(string="Date de naissance", required=True)
    # age = fields.Integer(string="Age", compute="_compute_age", store=True)

    # @api.depends('born_date')
    # def _compute_age(self):
    #     """Compute the current age of the beneficiary based on the born_date."""
    #     for record in self:
    #         if record.born_date:
    #             today = date.today()
    #             record.age = relativedelta(today, record.born_date).years
    #         else:
    #             record.age = 0