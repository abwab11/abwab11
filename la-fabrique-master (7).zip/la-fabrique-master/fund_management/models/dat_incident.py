from odoo import models, fields, api
from datetime import date

class FundManagementDatIncident(models.Model):
    _name = 'fund_management.dat_incident'
    _description = 'DAT Account Incident'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'id desc'
    
    name = fields.Char(string='Code', copy=False, readonly=True, default=lambda self: self.env['ir.sequence'].next_by_code('fund.management.dat_incident.sequence'))  # Auto-generated code
    incident_name = fields.Char(string="Nom de l'incident")
    start_date = fields.Date(string="Date de début", required=True)
    end_date = fields.Date(string="Date de fin", required=True)
    number_of_days = fields.Integer(string="Nombre de jours", compute='_compute_number_of_days', store=True)
    beneficiary_id = fields.Many2one('fund_management.bank', string="Bénéficiaire de la garantie", required=True)
    dossier_id = fields.Many2one('fund_management.demand', string="Dossier", 
                                 help="Filtré en fonction du bénéficiaire")
    account_id = fields.Many2one('fund_management.dat_account', string="Compte DAT", required=True)
    dossier_ids = fields.One2many('fund_management.demand', string='Dossiers', related='beneficiary_id.demand_ids')  # Linked dossiers
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)

    @api.depends('start_date', 'end_date')
    def _compute_number_of_days(self):
        for incident in self:
            if incident.start_date and incident.end_date:
                incident.number_of_days = (incident.end_date - incident.start_date).days
            else:
                incident.number_of_days = 0
