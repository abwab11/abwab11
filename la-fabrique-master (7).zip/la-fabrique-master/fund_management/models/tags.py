#-*- coding:utf-8 -*-
from odoo import models, fields, api,  _
import logging

_logger = logging.getLogger(__name__)

class Tags(models.Model):
    _name = 'fund_management.etiquette'
    _description = 'Etiquette'
    _order = 'id desc'

    name = fields.Char(string='Nom de l\'Étiquette', required=True)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
