#-*- coding:utf-8 -*-
from odoo import models, fields, api,  _
from odoo.exceptions import ValidationError
import logging

_logger = logging.getLogger(__name__)

class Funds(models.Model):
    _name = 'fund_management.funds'
    _description = 'Fund Management'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'id desc'

    name = fields.Char(string='Nom du Fonds', required=True)  # Name of the fund
    image = fields.Binary(string='Image')  # Image of the fund
    code = fields.Char(string='Code du Fonds', copy=False, readonly=True, default=lambda self: self.env['ir.sequence'].next_by_code('fund.sequence'))  # Auto-generated code
    valeur_actuelle = fields.Float(string='Solde', compute='_compute_valeur_actuelle',store=True)  # Current value of the fund
    date_creation = fields.Date(string='Date de Création', default=fields.Date.today())  # Creation date
    types_fonds = fields.Selection([('credit', 'Crédit'), ('subvention', 'Subvention'), ('mixte', 'Mixte')], string='Types de Fonds', required=True)  # Fund types
    bailleurs_ids = fields.Many2many('res.partner', string='Bailleurs', domain=[('is_company', '=', True)])  # Partners (filtered to only show companies)
    etiquette_ids = fields.Many2many('fund_management.etiquette', string='Étiquettes')  # Tags (labels)
    
    transaction_ids = fields.One2many('fund_management.transaction', 'fund_id', string='Transactions')  # Linked transactions
    dossier_ids = fields.One2many('fund_management.demand', 'fund_id', string='Dossiers')  # Linked dossiers
    woman_number = fields.Integer('Nombre de femme du fond', compute='compute_woman_number', store=True)
    state = fields.Selection([
        ('nouveau', 'Nouveau'),
        ('actif', 'Actif'),
        ('inactif', 'Inactif'),
    ], string="State", default="nouveau")
    is_intern_fund = fields.Boolean(string='Fonds interne?', required=True)  # Boolean for internal fund
    is_intern_fund_visibility = fields.Boolean(string='Fonds interne?', compute='_compute_is_intern_fund_visibility',store=True)
    max_amount = fields.Float(string='Montant maximum du dossier', required=True)  # Maximum amount for fund conditions
    subvention_max_amount = fields.Float(string='Montant maximum de la subvention')  # Maximum amount for fund conditions
    max_duration = fields.Integer(string='Durée maximum (Mois)')  # Maximum duration in months
    max_interest_rate = fields.Float(string='Taux d’intérêt maximum')  # Maximum interest rategi
    dat_account_ids = fields.Many2many('fund_management.dat_account', string="Comptes DAT")
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)

    @api.depends('dossier_ids.manager_gender')
    def compute_woman_number(self):
        woman_number = []
        for fund in self:
            if fund.dossier_ids:
                for dossier in fund.dossier_ids:
                    if dossier.manager_gender == 'female' and dossier.financial_institution_identifiant not in woman_number:
                        woman_number.append(dossier.financial_institution_identifiant)
            fund.woman_number = len(woman_number)
            
    # Calculate current value based on transactions
    @api.depends('transaction_ids.state', 'transaction_ids.montant')
    def _compute_valeur_actuelle(self):
        for fund in self:
            fund.valeur_actuelle = sum(t.montant for t in fund.transaction_ids if t.state == 'valider')
            
    # Calculate current value based on transactions
    @api.depends('is_intern_fund', 'types_fonds')
    def _compute_is_intern_fund_visibility(self):
        for fund in self:
            if fund.types_fonds != 'subvention' and fund.is_intern_fund:
                fund.is_intern_fund_visibility = True
            else:
                fund.is_intern_fund_visibility = False
            
    @api.constrains('is_intern_fund')
    def _check_internal_fund_conditions(self):
        """ Ensure no interest rates apply if the fund is internal. """
        for fund in self:
            if fund.is_intern_fund and fund.max_interest_rate:
                raise ValidationError(_('Cannot apply interest rate on internal fund.'))
            
    @api.constrains('subvention_max_amount')
    def _check_subvention_max_amount(self):
        """ Ensure no interest rates apply if the fund is internal. """
        for fund in self:
            if fund.max_amount < fund.subvention_max_amount:
                raise ValidationError(_("Le montant maximum de la subvention ne peut pas être supérieur au montant maximum du dossier."))