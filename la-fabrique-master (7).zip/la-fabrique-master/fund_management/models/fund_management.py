#-*- coding:utf-8 -*-
from odoo import models, fields, api,  _
from odoo.exceptions import ValidationError
from num2words import num2words

import logging

_logger = logging.getLogger(__name__)
class FundingRequest(models.Model):
    _name = 'fund_management.demand'
    _description = 'Demande de Financement'
    _inherit = ['customisable_workflow.work', 'mail.thread', 'mail.activity.mixin']
    _order = 'id desc'

    name = fields.Char(string='Nom du financement', required=True) 
    # Fields for the funding request
    numero_dossier = fields.Char(string="Numéro de dossier", default=lambda self: _('New'))
    type_demande = fields.Selection([
        ('subvention', 'Demande de subvention'),
        ('credit', 'Demande de crédit'),
        ('mixte', 'Mixte'),
    ], string="Type de demande")
    demand_type_id = fields.Many2one('fund_management.demand_type', string="Type de demande", required=True)
    is_subvention = fields.Boolean(string='Subvention ?', related='demand_type_id.is_subvention', store=True)
    is_credit = fields.Boolean(string='Credit ?', related='demand_type_id.is_credit', store=True)
    workflow_id = fields.Many2one('customisable_workflow.workflow', string='Workflow', related="demand_type_id.workflow_id")
    beneficiary_id = fields.Many2one('res.users', string="Bénéficiaire")
    financial_institution_id = fields.Many2one('fund_management.work_owner', string=u"Bénéficiaire")
    financial_institution_identifiant = fields.Integer(related='financial_institution_id.id', string=u"Id du Bénéficiaire", store=True)
    woman_number = fields.Integer('Nombre de femme du fond', related='fund_id.woman_number', store=True)
    responsable_id = fields.Many2one('res.users', string="Responsable du dossier", domain=lambda self: [('groups_id', 'in', self.env.ref('fund_management.fund_admin').id)])
    
    date_creation = fields.Date(string="Date de création", default=fields.Date.context_today)
    creation_year = fields.Integer(string="Année de création", compute='_compute_creation_year', store=True)
    state = fields.Selection([
        ('draft', 'Brouillon'),
        ('in_progress', 'En cours'),
        ('done', 'Validé'),
        ('cancelled', 'Annulé')
    ], string="Statut", default='draft', tracking=True)
    mixte = fields.Boolean(string='Mixte ? ', related="demand_type_id.mixte", store=True)

    # One-to-many relation for credit lines (linked to a custom credit line model)
    credit_line_ids = fields.One2many('fund_management.credit_line', 'demand_id', string="Lignes de crédits")
    amortization_lines_ids = fields.One2many('fund_management.amortization.line', string="Tableau d'amortissement" , related='credit_line_ids.amortization_lines_ids')

    load_schedule_ids = fields.One2many('fund_management.payment.schedule', string="Tableau d'amortissement",  related='credit_line_ids.load_schedule_ids')

    transaction_ids = fields.One2many('fund_management.transaction', 'dossier_id', string="Décaissements")
    possible_fund_ids = fields.Many2many('fund_management.funds', string="Fonds associés", related="demand_type_id.fund_ids")
    fund_mixte_ids = fields.Many2one('fund_management.funds', string="Fond mixte associés", related='fund_id')
    fund_id = fields.Many2one('fund_management.funds', string="Fonds")  # Show only related funds
    is_intern_fund = fields.Boolean(string='Fonds interne?', related='fund_id.is_intern_fund')
    is_intern_fund_mixte = fields.Boolean(string='Fonds interne?', compute="_compute_is_intern_fund_mixte")
    fund_value = fields.Float(string='Solde actuel du fond ', related="fund_id.valeur_actuelle", store=True)
    fund_value_on_setup = fields.Float(string='Solde du fonds à la mise en place')
    dat_value = fields.Float(string='Solde du compte DAT', related="dat_account_id.current_balance", store=True)
    possible_dat_account_ids = fields.Many2many('fund_management.dat_account', string="Compte DAT associé", related='fund_id.dat_account_ids')
    dat_account_id = fields.Many2one('fund_management.dat_account', string="Compte DAT associé", ondelete='cascade')
    total_guarantee_amount = fields.Float('Montant total garantie du dossier', compute='_compute_total_guarantee_amount',store=True)
    available_guarantee_amount = fields.Float('Montant disponible pour garantie', related='dat_account_id.available_guarantee_amount', store=True)
    is_fund_have_dat = fields.Boolean("Est ce que le font a des comptes DAT ?", compute='_compute_is_fund_have_dat')
    is_requester = fields.Boolean("Is request", compute='_compute_is_requester')
    get_one_dat = fields.Boolean("Get one dat")
    repayable_advance = fields.Boolean("Avez vous besoins d'une avance remboursable ?")
    repayable_advance_credit_line = fields.Boolean("Avez vous besoins d'une avance remboursable ?")
    subvention_amount = fields.Integer('Montant Total accordé')
    subvention_total_amount = fields.Integer('Montant total de la subvention')
    request_subvention_amount = fields.Integer('Montant du dossier')
    max_credit_amount = fields.Float("Montant maximum du crédit", related='fund_id.max_amount', store=True)
    request_credit_amount = fields.Integer("Montant du crédit demandé (Montant de l'avance remboursable)")
    credit_amount = fields.Integer('Montant du crédit accordé')
    total_disbursed_amount = fields.Integer('Montant total décaissé', compute='_compute_total_disbursed_amount', store=True)
    request_amount = fields.Integer('Montant total demandé')
    fund_subvention_max_amount = fields.Float('Montant maximum de la subvention', related='fund_id.max_amount', store=True)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
    total_credit_line_amount = fields.Float("Montant total des ligne de crédit", coxpute='_compute_total_credit_line_amount', store=True)
    remaining_disbursement = fields.Float('Remaining dissbursement', compute='_compute_remaining_disbursement', store=True)
    remaining_disbursement_for_sub = fields.Float('Remaining dissbursement', compute='_compute_remaining_disbursement_for_sub', store=True)
    description = fields.Text('Description')
    
    employee_count = fields.Integer(string="Nombre d'employés")
    female_employee_count = fields.Integer(string="Nombre d'employés femmes")
    young_employee_count = fields.Integer(string="Employés jeunes (-35 ans)")
    average_income = fields.Float(string="Revenu moyen")
    current_revenue = fields.Float(string="Chiffre d'affaire actuel")
    revenue_n_1 = fields.Float(string="CA N-1")
    revenue_n_2 = fields.Float(string="CA N-2")
    revenue_n_3 = fields.Float(string="CA N-3")
    jobs_created = fields.Integer(string="Nombre d'emplois créés")
    jobs_consolidated = fields.Integer(string="Nombre d'emplois consolidés")
    current_monthly_revenue = fields.Float(string="CA mensuel actuel")
    post_funding_monthly_revenue = fields.Float(string="CA mensuel après financement")

    total_paid_amount = fields.Float(string="Montant total remboursé", compute='_compute_total_paid_amount', store=True)
    total_unpaid_count = fields.Float(string=u"Nombre d'impayé", compute='_compute_total_unpaid_count', store=True)
    total_unpaid_amount = fields.Float(string=u"Montant des impayés qui ont dépassés 30  jours de retard", compute='_compute_total_unpaid_amount', store=True)
    remaining_amount_to_pay = fields.Float(string=u"Montant restant à payer", compute='_compute_remaining_amount_to_pay', store=True)
    remaining_amount_am_to_pay = fields.Float(string=u"Montant restant à payer", compute='_compute_remaining_amount_am_to_pay', store=True)

    total_am_paid_amount = fields.Float(string="Montant total remboursé", compute='_compute_total_am_paid_amount', store=True)
    total_am_unpaid_count = fields.Float(string=u"Nombre d'impayé", compute='_compute_total_am_unpaid_count', store=True)
    total_am_unpaid_amount = fields.Float(string=u"Montant des impayés qui ont dépassés 30  jours de retard", compute='_compute_total_am_unpaid_amount', store=True)
    object_id = fields.Many2one('fund_management.object', string="Objet de la demande")
    possible_object_ids = fields.Many2many('fund_management.object', string="Objet de la demande", related="demand_type_id.object_ids")
    base_url = fields.Char(string="Base URL", compute='_compute_guarantee_link') 
    
    # Beneficiary
    
    ninea = fields.Char(string='NINEA/IFU', related='financial_institution_id.ninea', store=True)
    capital = fields.Char(string='Capital', related='financial_institution_id.capital', store=True)
    acronym = fields.Char(string='Abrégé', related='financial_institution_id.acronym', store=True)
    business_sector_id = fields.Many2one("fund_management.business_sector", string=u"Secteur d'activité", related='financial_institution_id.business_sector_id', store=True)
    rccm = fields.Char(string="RCCM", related='financial_institution_id.rccm', store=True)
    legal_status = fields.Many2one("fund_management.legal_status" ,string="Forme juridique", related='financial_institution_id.legal_status', store=True)
    faculty = fields.Many2one("fund_management.faculty" ,string=u"Filière", related='financial_institution_id.faculty', store=True)
    manager_gender = fields.Selection([('male', "Homme"), ('female', "Femme")] ,string="Genre du dirigeant", related='financial_institution_id.manager_gender', store=True)
    leader_last_name = fields.Char(string="Nom du dirigeant", related='financial_institution_id.leader_last_name', store=True)
    leader_first_name = fields.Char(string="Prénom du dirigeant", related='financial_institution_id.leader_first_name', store=True)
    born_date = fields.Date(string="Date de naissance", related='financial_institution_id.born_date', store=True)
    age = fields.Integer(string="Age", related='financial_institution_id.age', store=True)
    # leader_email= fields.Char(string="Email du dirigeant", related='financial_institution_id.leader_email', store=True)
    # leader_phone_number= fields.Char(string="Téléphone du dirigeant", related='financial_institution_id.leader_phone_number', store=True)
    # leader_title= fields.Char(string="Poste du dirigeant", related='financial_institution_id.leader_title', store=True)
    # status_id = fields.Many2one('fund_management.status', string='Statut', related='financial_institution_id.status_id', store=True)
    # status_name = fields.Char('Statut', related='status_id.name', related='financial_institution_id.status_name', store=True)

    @api.depends('credit_line_ids')  
    def _compute_total_guarantee_amount(self):
        for record in self:
            if record.credit_line_ids:
                record.total_guarantee_amount = sum((t.garantee_amount) for t in record.credit_line_ids)
            else:
                record.total_guarantee_amount = 0

    @api.depends('date_creation')
    def _compute_creation_year(self):
        for record in self:
            if record.date_creation:
                record.creation_year = record.date_creation.year
            else:
                record.creation_year = False

    @api.model
    def create(self, vals):
        if vals.get('numero_dossier', _('New')) == _('New'):
            vals['numero_dossier'] = self.env['ir.sequence'].next_by_code('fund.management.sequence')
        return super().create(vals)
    
    def update_sequence(self):
        # Get all records where 'numero_dossier' is 'New' or empty
        records_to_update = self.env['fund_management.demand'].search([('numero_dossier', '=', False)])

        # Update the 'numero_dossier' field with the sequence
        for record in records_to_update:
            record.numero_dossier = self.env['ir.sequence'].next_by_code('fund.management.sequence')

        
    
    def _compute_guarantee_link(self):
        url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        url += '/web#id=%d&view_type=form&model=%s' % (self.id, self._name)
        self.base_url = url

    def format_amount(self, amount, currency="FCFA"):
            # Format the amount with spaces as thousands separator
        amount_str = f"{amount:,}".replace(",", " ")
        # Add the currency suffix
        return f"{amount_str} {currency}"   
    
    def format_date(self, date):
        return date.strftime('%d/%m/%Y')

    @api.depends('credit_line_ids.amortization_lines_ids')
    def _compute_amortization_lines_ids(self):
        amortization_ids = []
        for record in self:
            if record.credit_line_ids:
                for line in record.credit_line_ids:
                    for am in line.amortization_lines_ids:
                        amortization_ids.append(am)
            record.amortization_lines_ids = [(6, 0, amortization_ids)]
            

    def format_amount_in_words(self, amount, currency="FCFA"):
        # Convert number to words in French
        amount_in_words = num2words(amount, lang='fr')
        # Format the number with spaces as thousands separator
        amount_str = f"{amount:,}".replace(",", " ")
        # Combine formatted number and words with currency
        return f"{amount_str} {currency} ({amount_in_words.capitalize()} {currency})"  
    
      
    def format_amount_only(self, amount):
            # Format the amount with spaces as thousands separator
        amount_str = f"{amount:,}".replace(",", " ")
        # Add the currency suffix
        return f"{amount_str}"     
    
    def get_total_amount(self):
        for record in self:
            return record.subvention_amount + record.credit_amount

    @api.depends('credit_line_ids.total_am_unpaid_amount')  
    def _compute_total_am_unpaid_amount(self):
        for record in self:
            if record.credit_line_ids:
                record.total_am_unpaid_amount = sum((t.total_am_unpaid_amount) for t in record.credit_line_ids)
            else:
                record.total_am_unpaid_amount = 0

    @api.depends('credit_line_ids.total_am_unpaid_count')  
    def _compute_total_am_unpaid_count(self):
        for record in self:
            if record.credit_line_ids:
                record.total_am_unpaid_count = sum((t.total_am_unpaid_count) for t in record.credit_line_ids)
            else:
                record.total_am_unpaid_count = 0

    @api.depends('credit_line_ids.total_am_paid_amount')  
    def _compute_total_am_paid_amount(self):
        for record in self:
            if record.credit_line_ids:
                record.total_am_paid_amount = sum((t.total_am_paid_amount) for t in record.credit_line_ids)
            else:
                record.total_am_paid_amount = 0

    @api.depends('total_paid_amount', 'total_credit_line_amount' )  
    def _compute_remaining_amount_to_pay(self):
        for record in self:
            if record.total_credit_line_amount:
                record.remaining_amount_to_pay = record.total_credit_line_amount - record.total_paid_amount
            else:
                record.remaining_amount_to_pay = 0
                
    @api.depends('total_paid_amount', 'total_am_paid_amount' )  
    def _compute_remaining_amount_am_to_pay(self):
        for record in self:
            if record.total_credit_line_amount:
                record.remaining_amount_am_to_pay = record.total_credit_line_amount - record.total_am_paid_amount
            else:
                record.remaining_amount_am_to_pay = 0
                
    @api.depends('credit_line_ids.total_unpaid_amount')  
    def _compute_total_unpaid_amount(self):
        for record in self:
            if record.credit_line_ids:
                record.total_unpaid_amount = sum((t.total_unpaid_amount) for t in record.credit_line_ids)
            else:
                record.total_unpaid_amount = 0
                
    @api.depends('credit_line_ids.total_unpaid_count')  
    def _compute_total_unpaid_count(self):
        for record in self:
            if record.credit_line_ids:
                record.total_unpaid_count = sum((t.total_unpaid_count) for t in record.credit_line_ids)
            else:
                record.total_unpaid_count = 0
                
    @api.depends('credit_line_ids.total_paid_amount')  
    def _compute_total_paid_amount(self):
        for record in self:
            if record.credit_line_ids:
                record.total_paid_amount = sum((t.total_paid_amount) for t in record.credit_line_ids)
            else:
                record.total_paid_amount = 0

    @api.depends('credit_amount', 'total_disbursed_amount')
    def _compute_remaining_disbursement(self):
        for demand in self:
            if demand.credit_amount > 0 and demand.total_disbursed_amount > 0:
                demand.remaining_disbursement = demand.credit_amount - demand.total_disbursed_amount
            else:
                demand.remaining_disbursement = 0
                
    @api.depends('subvention_amount', 'total_disbursed_amount')
    def _compute_remaining_disbursement_for_sub(self):
        for demand in self:
            if demand.subvention_amount > 0 and demand.total_disbursed_amount > 0:
                demand.remaining_disbursement_for_sub = demand.subvention_amount - demand.total_disbursed_amount
            else:
                demand.remaining_disbursement_for_sub = 0

    # @api.constrains('request_credit_amount', 'max_credit_amount', 'credit_amount', 'total_disbursed_amount')
    # def check_credit_amount(self):
    #     for demand in self:
    #         # Check if the requested credit amount exceeds the maximum allowed
    #         if demand.request_credit_amount > demand.max_credit_amount and demand.max_credit_amount > 0:
    #             raise ValidationError("Le montant du crédit demandé ne doit pas excéder le montant maximum du crédit configuré sur le fonds.")
            
    #         # Check if the approved credit exceeds the max credit amount or total line credits
    #         if demand.credit_amount > demand.max_credit_amount and demand.max_credit_amount > 0:
    #             raise ValidationError("Le montant total du crédit accordé ne doit pas dépasser le montant maximum configuré sur le fonds.")
            
    #         # Check if total disbursements exceed approved credit amount
    #         if demand.total_disbursed_amount > demand.credit_amount and demand.credit_amount > 0 and not demand.mixte:
    #             raise ValidationError("La somme des décaissements ne peut pas excéder le montant total du crédit accordé.")

    # Calculate current value based on transactions
    @api.depends('transaction_ids.state')
    def _compute_total_disbursed_amount(self):
        for record in self:
            record.total_disbursed_amount = sum(-(t.montant) for t in record.transaction_ids if t.state == 'valider')
            # if record.total_disbursed_amount  > record.credit_amount:
            #     pass
                # raise ValidationError("La somme des décaissements ne peut pas excéder le montant total du crédit accordé.")
    
    @api.depends('credit_line_ids')
    def _compute_total_credit_line_amount(self):
        for record in self:
            if record.credit_line_ids:
                record.total_credit_line_amount = sum((t.loan_amount) for t in record.credit_line_ids)
            else:
                record.total_credit_line_amount = 0
            
    @api.depends('fund_mixte_ids', 'is_intern_fund', 'fund_id')
    def _compute_is_intern_fund_mixte(self):
        for record in self:
            if record.fund_mixte_ids and record.fund_id:
                record.is_intern_fund_mixte = True
            elif record.fund_mixte_ids and not record.fund_id:
                record.is_intern_fund_mixte = True
            elif not record.fund_mixte_ids and record.fund_id:
                if record.is_intern_fund:
                    record.is_intern_fund_mixte = True
                else:
                    record.is_intern_fund_mixte = False
            else:
                record.is_intern_fund_mixte = False
            

    @api.constrains('current_step_id', 'fund_id')
    def _fund_value_on_setup(self):
        for record in self:
            if record.current_step_id.is_setup_step:
                record.fund_value_on_setup = record.fund_id.valeur_actuelle
            
    @api.constrains('request_subvention_amount', 'repayable_advance', 'subvention_amount')
    def _compute_repayable_advance_credit_line(self):
        for record in self:
            if record.repayable_advance:
                request_subvention_amount = record.request_subvention_amount
                subvention_amount = record.subvention_amount
                total_subvention = 0
                credit_line_amount = 0
                if request_subvention_amount > 350000:
                    total_subvention =  max(subvention_amount * 0.7, 350000)
                    credit_line_amount = subvention_amount - total_subvention
                    record.credit_amount = credit_line_amount
                    record.request_credit_amount = credit_line_amount
                    record.subvention_total_amount = total_subvention
                else:
                    total_subvention = request_subvention_amount
                    credit_line_amount = 0
                    record.credit_amount = 0
                    record.request_credit_amount = 0
                    record.subvention_total_amount = 0

                record.credit_line_ids = [(5, 0, 0)]
                if credit_line_amount > 0:
                    record.credit_line_ids.create({
                        'demand_id': record.id,
                        'loan_amount': float(credit_line_amount)
                    })
            else:
                record.credit_line_ids = [(5, 0, 0)]
                record.credit_amount = 0
                record.request_credit_amount = 0
                record.subvention_total_amount = 0
                
            # record.repayable_advance_credit_line = True
            
    @api.depends('fund_mixte_ids.types_fonds', 'fund_mixte_ids.subvention_max_amount')
    def _compute_fund_subvention_max_amount(self):
        for record in self:
            record.fund_subvention_max_amount = sum(t.subvention_max_amount for t in record.fund_mixte_ids if t.types_fonds == 'mixte')
    
    # @api.constrains('subvention_amount', 'total_disbursed_amount', 'request_subvention_amount', 'fund_subvention_max_amount')
    # def check_subvention_amount(self):
    #     for demand in self:
    #         if demand.is_subvention or demand.mixte:
    #             if demand.total_disbursed_amount > demand.subvention_amount:
    #                 raise ValidationError('le champs montant total décaissé qui ne peux pas excéder celui de la subvention.')
    #             if demand.subvention_amount > demand.fund_subvention_max_amount and demand.fund_subvention_max_amount > 0:
    #                 raise ValidationError('Le montant de la subvention ne peux pas excéder le montant maximum de la subventions.')
    #             if demand.subvention_amount > demand.fund_subvention_max_amount and demand.fund_subvention_max_amount > 0 or demand.total_disbursed_amount > demand.fund_subvention_max_amount and demand.fund_subvention_max_amount > 0:
    #                 raise ValidationError("Vous ne pouvez pas excéder le montant total de la subvention.")
    #             if demand.request_subvention_amount > demand.fund_subvention_max_amount and demand.fund_subvention_max_amount > 0:
    #                 raise ValidationError("Vous ne pouvez pas excéder le montant maximun de la subvention.")
    
    @api.depends('beneficiary_id')
    def _compute_is_requester(self):
        for record in self:
            if record.env.user.has_group('fund_management.fund_requester_group'):
                record.is_requester = True
            else:
                record.is_requester = False
                
    @api.depends('possible_fund_ids')
    def _compute_get_one_dat(self):
        for record in self:
            if record.possible_fund_ids and len(record.possible_fund_ids) == 1:
                record.dat_account_id = record.possible_fund_ids[0].id
            
                record.get_one_dat = True
            else:
                record.get_one_dat = False
    
    @api.depends('possible_dat_account_ids')
    def _compute_is_fund_have_dat(self):
        for record in self:
            if record.possible_dat_account_ids:
                record.is_fund_have_dat = True
            else:
                record.is_fund_have_dat = False

    # Constraint to check the credit line conditions based on the selected fund
    @api.constrains('credit_line_ids', 'fund_id')
    def _check_fund_conditions(self):
        for record in self:
            if record.fund_id:
                max_amount = record.fund_id.max_amount
                max_duration = record.fund_id.max_duration
                max_interest_rate = record.fund_id.max_interest_rate

                for credit_line in record.credit_line_ids:
                    if max_amount and credit_line.loan_amount > max_amount:
                        raise ValidationError(_('The credit line amount cannot exceed %s for this fund.') % max_amount)
                    if max_duration and credit_line.duration_in_month > max_duration:
                        raise ValidationError(_('The credit line duration cannot exceed %s months for this fund.') % max_duration)
                    if max_interest_rate and credit_line.interest_rate > max_interest_rate:
                        raise ValidationError(_('The interest rate cannot exceed %s%% for this fund.') % max_interest_rate)

    # State transitions / workflow logic
    def action_submit(self):
        self.write({'state': 'in_progress'})

    def action_validate(self):
        self.write({'state': 'done'})

    def action_cancel(self):
        self.write({'state': 'cancelled'})
        
    def run_cron_for_update(self):
        data = self.env['fund_management.demand'].search([])
        if data:
            for record in data:
                record._compute_total_paid_amount()
                record._compute_remaining_disbursement()
                record._compute_total_guarantee_amount()
                record._compute_total_am_unpaid_amount()
                record._compute_total_am_unpaid_count()
                record._compute_total_am_paid_amount()
                record._compute_remaining_amount_to_pay()
                record._compute_remaining_amount_am_to_pay()
                record._compute_total_unpaid_amount()
                record._compute_total_unpaid_count()
                record._compute_remaining_disbursement()
                record._compute_remaining_disbursement_for_sub()
                record._compute_total_disbursed_amount()
                record._compute_total_credit_line_amount()
                
                