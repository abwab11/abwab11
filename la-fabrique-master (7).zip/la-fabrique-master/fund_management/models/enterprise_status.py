#-*- coding:utf-8 -*-
from odoo import models, fields, api, _

class EnterpriseStatus(models.Model):
    _name = 'fund_management.status'
    _order = "name asc"
    _description = "Filière"
    
    name = fields.Char(string=u'Nom', required=True)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)