#-*- coding:utf-8 -*-
from odoo import models, fields, api,  _
from odoo.exceptions import ValidationError
from datetime import date

import logging

_logger = logging.getLogger(__name__)

class LoanPaymentSchedule(models.Model):
    _name = 'fund_management.payment.schedule'
    _description = 'Loan Payment Schedule'
    _order = 'id asc'

    credit_line_id = fields.Many2one('fund_management.credit_line', string="Ligne de crédit", ondelete="cascade")
    number = fields.Integer(string="N°")
    repayment_date = fields.Date(string="Date d'échéance")
    amount = fields.Float(string="Montant")
    payment_date = fields.Date(string="Date de paiement")
    cumul_payment = fields.Float(string="Cumul paiement")
    remaining_amount = fields.Float(string="Reste à payer")
    # cumul_paiement = fields.Float(string="Cumul paiement", compute='_compute_cumul_paiement', store=True)
    # reste_a_payer = fields.Float(string="Reste à payer", compute='_compute_reste_a_payer', store=True)
    comments = fields.Text(string="Commentaires")
    transaction_ids = fields.One2many('fund_management.payment', 'loan_id', string="Paiement")
    total_payment = fields.Float(string="Montant total payé", compute='_compute_total_payment',store=True)
    remaining_to_pay = fields.Float(string="Reste à payer", compute='_compute_remaining_to_pay',store=True)
    excess_payment_processed = fields.Boolean(string="Excess Payment Processed", default=False)
    formatted_amount = fields.Char(compute='_compute_formatted_amount', string='Formatted amount',store=True)
    formatted_date = fields.Char(compute='_compute_formatted_date', string='Formatted date',store=True)

    state = fields.Selection([
            ('paid', 'Payé'),
            ('unpaid', 'Impayé'),
            ('late_payment', 'Paiement en retard'),
            ('non_echu', 'Non echu'),
            ('partial', 'Paiement partiel'),
        ], string='Statut', default='late_payment') 

    @api.depends('amount')
    def _compute_formatted_amount(self):
        for record in self:
            if record.amount:
                # Format the amount with spaces as thousands separator
                record.formatted_amount = f"{record.amount:,.0f}".replace(",", " ")
            else:
                record.formatted_amount = ""

    @api.depends('repayment_date')
    def _compute_formatted_date(self):
        for record in self:
            if record.repayment_date:
                record.formatted_date = record.repayment_date.strftime('%d/%m/%Y')
            else:
                record.formatted_date = ""

    @api.depends('remaining_to_pay', 'payment_date', 'total_payment', 'repayment_date', 'amount')
    def _compute_state(self):
        for record in self:
            # Non-echu: Payment date not due yet and no payment made
            if not record.payment_date and record.repayment_date > date.today():
                record.state = 'non_echu'
            # Paid: Amount fully paid on or before repayment date
            elif record.payment_date and record.total_payment >= record.amount:
                record.state = 'paid'
                # Handle the case where excess payment is made, and transfer it to the next installment
                if record.total_payment > record.amount and not record.excess_payment_processed:
                    excess_payment = record.total_payment - record.amount
                    next_payment = record.env['fund_management.payment.schedule'].search([
                        ('number', '=', record.number + 1),
                        ('credit_line_id', '=', record.credit_line_id.id)
                    ], limit=1)
                    if next_payment:
                        t = self.env['fund_management.payment'].create({
                            'amount': excess_payment,
                            'loan_id': next_payment.id,
                        })
                        record.excess_payment_processed = True
            # Late Payment: Payment due date has passed, and total payment is still less than amount
            elif date.today() > record.repayment_date and record.total_payment < record.amount:
                record.state = 'late_payment'
            # Partial: Some payment made, but less than the amount due
            elif record.total_payment > 0 and record.total_payment < record.amount:
                record.state = 'partial'
            # Unpaid: No payment made, and repayment date has passed
            else:
                record.state = 'unpaid'
   
    # @api.depends('remaining_to_pay', 'payment_date', 'total_payment') 
    # def _compute_state(self):
    #     for record in self:
    #         if record.payment_date and record.amount <= record.total_payment:
    #             record.state = 'paid'
    #             if record.amount <= record.total_payment:
    #                 exceed = record.total_payment - record.amount
    #                 payment = record.env['fund_management.payment.schedule'].search([('number', '=', record.number + 1)])
    #                 if payment:
    #                     new_payment = record.env['und_management.payment'].create({
    #                         'amount': exceed,
    #                         'loan_id': payment.id
    #                     })
    #         elif record.payment_date > record.repayment_date and record.total_payment < record.amount:
    #             record.state = 'late_payment' 
    #         else:
    #           record.state = 'impaid'  
    
    @api.depends('transaction_ids.state')
    def _compute_total_payment(self):
        for record in self:
            if record.transaction_ids:
                record.total_payment = sum((t.amount) for t in record.transaction_ids if t.state == 'valider')
            else:
                record.total_payment = 0
    
    @api.depends('total_payment', 'amount')
    def _compute_remaining_to_pay(self):
        for record in self:
            if record.amount and record.total_payment:
                record.remaining_to_pay = record.amount - record.total_payment
            else:
                record.remaining_to_pay = 0

    # @api.constrains('total_payment', 'amount')
    # def check_total_payment(self):
    #     for record in self:
    #         if record.total_payment and record.amount:
    #             if record.total_payment > record.amount:
    #                 raise ValidationError("Vous ne pouvez pas payer plus que le montant de la ligne.")