# -*- coding: utf-8 -*-
from odoo import api, fields, models

class Person(models.Model):
    _name = "fund_management.person"
    _description = 'Person model'

    name = fields.Char(string='Nom', compute='_compute_name', store=True)
    first_name = fields.Char(string=u'Prénom', required=True)
    last_name = fields.Char(string='Nom', required=True)
    civility = fields.Selection([('Monsieur', 'Monsieur'),('Madame', 'Madame')], string=u"Civilité", required=True)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
    
    @api.depends('first_name','last_name')
    def _compute_name(self):
        self.name = str(self.first_name)+" "+str(self.last_name)

