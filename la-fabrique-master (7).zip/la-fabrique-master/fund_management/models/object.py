#-*- coding:utf-8 -*-
from odoo import models, fields, api,  _
import logging

_logger = logging.getLogger(__name__)

class Object(models.Model):
    _name = 'fund_management.object'
    _description = 'Objet de demande'
    _order = 'id desc'

    name = fields.Char(string='Objet de la demande', required=True)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
