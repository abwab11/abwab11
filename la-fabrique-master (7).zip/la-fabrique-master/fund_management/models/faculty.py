#-*- coding:utf-8 -*-
from odoo import models, fields, api, _

class Faculty(models.Model):
    _name = 'fund_management.faculty'
    _order = "name asc"
    _description = "Filière"
    
    name = fields.Char(string=u'Filière', required=True)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)