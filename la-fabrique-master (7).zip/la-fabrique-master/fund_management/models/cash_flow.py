#-*- coding:utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from datetime import date
from odoo.tools.misc import formatLang
from dateutil.relativedelta import relativedelta
import logging
_logger = logging.getLogger(__name__)

class CashFlowLine(models.Model):
    _name = 'fund_management.cash_flow.line'
    _description = 'Cash Flow Line'
    
    month = fields.Char(string="Mois", required=True)
    expected_income = fields.Float("TOTAL CHIFFRE D'AFFAIRES")
    credit_line_id = fields.Many2one('fund_management.credit_line', string="Ligne de crédit", ondelete="cascade")
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)