# -*- coding: utf-8 -*-
from odoo import api, fields, models
from dateutil.relativedelta import relativedelta
from datetime import date
class FinancialInstitution(models.Model):
    _inherit = ["fund_management.work_owner"]
    
    ninea = fields.Char(string='NINEA/IFU', required=True)
    capital = fields.Char(string='Capital')
    acronym = fields.Char(string='Abrégé', required=True)
    managing_director_ids = fields.One2many('fund_management.manager', 'work_owner_id', string="Dirigeants")
    bank_id = fields.Many2one('res.bank', string='Banque')
    general_manager_id = fields.Many2one('fund_management.manager', string='Directeur général')
    business_sector_id = fields.Many2one("fund_management.business_sector", string=u"Secteur d'activité")
    rccm = fields.Char(string="RCCM")
    legal_status = fields.Many2one("fund_management.legal_status" ,string="Forme juridique")
    faculty = fields.Many2one("fund_management.faculty" ,string=u"Filière")
    manager_gender = fields.Selection([('male', "Homme"), ('female', "Femme")] ,string="Genre du dirigeant", required=True)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
    leader_last_name = fields.Char(string="Nom du dirigeant")
    leader_first_name = fields.Char(string="Prénom du dirigeant")
    born_date = fields.Date(string="Date de naissance", required=True)
    age = fields.Integer(string="Age", compute="_compute_age", store=True)
    demand_ids = fields.One2many('fund_management.demand', 'financial_institution_id', string="Dossiers")

    @api.depends('born_date')
    def _compute_age(self):
        """Compute the current age of the beneficiary based on the born_date."""
        for record in self:
            if record.born_date:
                today = date.today()
                record.age = relativedelta(today, record.born_date).years
            else:
                record.age = 0
    
    def get_leader_full_name(self):
        return str(self.leader_first_name) + ' ' + str(self.leader_last_name)