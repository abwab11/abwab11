from odoo import api, fields, models


class ResUsers(models.Model):
    _inherit = 'res.users'
    
    partner_manager_ids = fields.One2many('fund_management.partner_manager', 'user_id', string="Managers")
    demand_ids = fields.One2many('fund_management.demand', 'beneficiary_id', string="Dossier de guarantie")
    work_owner_id = fields.Many2one('fund_management.work_owner', string="Institution", compute="_compute_work_owner_id", store=True)
    
    @api.depends('partner_manager_ids')
    def _compute_work_owner_id(self):
        for user in self:
            if user.partner_manager_ids:
                user.work_owner_id = user.partner_manager_ids[0].work_owner_id.id
            else:
                user.work_owner_id = False
                