# -*- coding: utf-8 -*-
from odoo import api, fields, models
import logging
_logger = logging.getLogger(__name__)
class PartnerManager(models.Model):
    _name = "fund_management.partner_manager"
    _inherits = {'res.users' : 'user_id'}
    _description = "Partner manager"

    user_id = fields.Many2one('res.users', string='Utilisateur', required=True, ondelete="cascade")
    work_owner_id = fields.Many2one('fund_management.work_owner', string=u'Entité', required=True)
    first_name = fields.Char(string=u'Prénom', required=True)
    last_name = fields.Char(string='Nom', required=True)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
    
    @api.model_create_multi
    def create(self, vals_list):
        partner_managers = super(PartnerManager, self).create(vals_list)
        for partner_manager in partner_managers:
            partner_manager.groups_id = [(4, self.env.ref('base.group_user').id)]
            partner_manager.groups_id = [(4, self.env.ref('fund_management.fund_requester_group').id)]
        return partner_managers
    
    @api.onchange('first_name','last_name')
    def _onchange_name(self):
        self.name = str(self.first_name)+" "+str(self.last_name)
    
    @api.onchange('login')
    def _onchange_login(self):
        self.email = self.login