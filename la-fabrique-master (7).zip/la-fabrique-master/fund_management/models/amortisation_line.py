#-*- coding:utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from datetime import date
from calendar import monthrange

from odoo.tools.misc import formatLang
from dateutil.relativedelta import relativedelta
from datetime import timedelta
import logging
_logger = logging.getLogger(__name__)

class AmortizationLine(models.Model):
    _name = 'fund_management.amortization.line'
    _description = 'Amortization Line'

    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
    installment_number = fields.Integer(string="Numéro de l'échéance")
    month = fields.Date(string="Mois")
    forecast_revenue = fields.Float(string=u"Chiffre d'affaires réel")
    forecast_revenue_euro = fields.Float(string=u"Chiffre d'affaires réel en Euro", compute='_compute_forecast_revenue_euro', store=True)
    forecast_revenue_estimated = fields.Float(string="Chiffre d'affaires prévisionnel")
    forecast_revenue_estimated_euro = fields.Float(string="Chiffre d'affaires prévisionnel en Euro", compute='_compute_forecast_revenue_estimated_euro', store=True)
    refund_amount = fields.Float(string="Montant effectivement remboursé")
    comment = fields.Char(string="Commentaire")
    capital_repaid = fields.Float(string="Montant du capital à rembourser", compute='_compute_capital_repaid', readonly=False, store=True)
    capital_due = fields.Float(string="Capital restant dû")
    interest_repaid = fields.Float(string="Montant des intérêts à rembourser", compute='_compute_monthly_interest',store=True, readonly=False)
    real_interest_repaid = fields.Float(string=u"Montant des intérets effectivement remboursé")
    total_monthly_repayment = fields.Float(string="Montant total mensuel à rembourser", compute="_compute_total_repayment", store=True, readonly=False)
    real_total_monthly_repayment = fields.Float(string="Montant total (capital+intérêts) effectivement  remboursé",  compute="_compute_real_total_monthly_repayment", store=True,)
    remain_to_be_paid = fields.Float(string="Reste à remboursemer", compute="_compute_remain_to_be_paid", store=True)
    repaid_amount = fields.Float(string="Montant du remboursement", compute="_compute_repaid_amount", store=True)
    credit_line_id = fields.Many2one('fund_management.credit_line', string="Ligne de crédit", ondelete="cascade")
    differed_in_month = fields.Boolean("Appliquer le différé ? ")
    is_differed = fields.Boolean("Appliquer le différé ? ")
    refund_made = fields.Selection([
        ('no', 'Non'),
        ('yes', 'Oui')
    ], string="Remboursement effectué(Oui/Non)")
    early_repayment = fields.Selection([
        ('no', 'Non'),
        ('yes', 'Oui')
    ], string="Remboursement par anticipation?", compute='_compute_early_repayment',store=True)
    repayment_date = fields.Date(string="Date de remboursement", compute="_compute_repayment_date")
    financial_institution_id = fields.Many2one('fund_management.work_owner', string="Bénéficiaire", related='credit_line_id.financial_institution_id', store=True)

    def format_amount(self, amount, currency="FCFA"):
            # Format the amount with spaces as thousands separator
        amount_str = f"{amount:,}".replace(",", " ")
        # Add the currency suffix
        return f"{amount_str} {currency}"   
    
    def format_date(self, date):
        return date.strftime('%d/%m/%Y')

    @api.depends('forecast_revenue')
    def _compute_forecast_revenue_euro(self):
        euro = self.env['ir.config_parameter'].sudo().get_param('fund.euro')
        for record in self:
            if record.forecast_revenue:
                record.forecast_revenue_euro = record.forecast_revenue /float(euro)
            else:    
                record.forecast_revenue_euro = False
                
    @api.depends('forecast_revenue_estimated')
    def _compute_forecast_revenue_estimated_euro(self):
        euro = self.env['ir.config_parameter'].sudo().get_param('fund.euro')
        for record in self:
            if record.forecast_revenue_estimated:
                record.forecast_revenue_estimated_euro = record.forecast_revenue_estimated / float(euro)
            else:    
                record.forecast_revenue_estimated_euro = False
                
    @api.depends('total_monthly_repayment', 'refund_amount')
    def _compute_early_repayment(self):
        for record in self:
            if record.total_monthly_repayment and record.refund_amount:
                if (record.total_monthly_repayment - record.refund_amount) < 0:
                    record.early_repayment = 'yes'
                else:
                    record.early_repayment = 'no'
            else:    
                record.early_repayment = False

    @api.depends('early_repayment', 'total_monthly_repayment', 'refund_amount')
    def _compute_repaid_amount(self):
        for record in self:
            if record.early_repayment == 'yes':
                if  record.refund_amount and record.total_monthly_repayment:
                    record.repaid_amount = record.refund_amount - record.total_monthly_repayment
                else:
                    record.repaid_amount = 0
            else:
                record.repaid_amount = 0
                    

    @api.depends('refund_amount', 'total_monthly_repayment')
    def _compute_remain_to_be_paid(self):
        for record in self:
            if record.total_monthly_repayment and record.refund_amount:
                result = (record.total_monthly_repayment - record.refund_amount)
                record.remain_to_be_paid = -(result) if result < 0 else result
            else:
                record.remain_to_be_paid = 0

    @api.depends('refund_made')
    def _compute_repayment_date(self):
        for record in self:
            if record.refund_made == 'yes':
                record.repayment_date = fields.Date.today()
            else:
                record.repayment_date

    @api.depends('forecast_revenue', 'credit_line_id.turnover_interest')
    def _compute_capital_repaid(self):
        for record in self:
            turnover_interest = record.credit_line_id.turnover_interest / 100
            if turnover_interest > 0 and record.forecast_revenue > 0 and record.is_differed != True:
                record.capital_repaid = record.forecast_revenue * turnover_interest
            else:
                record.capital_repaid = 0

    @api.depends('capital_due', 'credit_line_id.interest_rate', 'credit_line_id.etablishment_date')
    def _compute_monthly_interest(self):
        for record in self:
            interest = record.credit_line_id.interest_rate / 100
            if interest > 0 and record.capital_due > 0:
                if record.installment_number == 1:
                    etablishment_date = record.credit_line_id.etablishment_date
                    days_in_month = monthrange(etablishment_date.year, etablishment_date.month)[1]
                    last_day_of_month = etablishment_date.replace(day=days_in_month)

                    # Calculate the number of days from etablishment_date to the last day of the month
                    days_remaining = (last_day_of_month - etablishment_date).days + 1  # Include the starting day

                                        
                    record.interest_repaid = record.capital_due * days_remaining / days_in_month * interest
                else:
                    record.interest_repaid = record.capital_due * interest
            else:
                record.interest_repaid = 0

    @api.depends('capital_repaid', 'interest_repaid')
    def _compute_total_repayment(self):
        for record in self:
            record.total_monthly_repayment = record.capital_repaid + record.interest_repaid
            
    @api.depends('refund_amount', 'real_interest_repaid')
    def _compute_real_total_monthly_repayment(self):
        for record in self:
            record.real_total_monthly_repayment = record.refund_amount + record.real_interest_repaid