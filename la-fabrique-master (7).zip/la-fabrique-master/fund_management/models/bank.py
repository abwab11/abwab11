# -*- coding: utf-8 -*-
from odoo import api, fields, models
from dateutil.relativedelta import relativedelta
from datetime import date
class Bank(models.Model):
    _name = "fund_management.bank"
    _inherits = {'fund_management.work_owner' : 'financial_institution_id'}
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'id desc'

    financial_institution_id = fields.Many2one('fund_management.work_owner', string=u'Institution financière')
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
    leader_email= fields.Char(string="Email du dirigeant")
    leader_phone_number= fields.Char(string="Téléphone du dirigeant")
    leader_title= fields.Char(string="Poste du dirigeant")
    status_id = fields.Many2one('fund_management.status', string='Statut', required=True)
    status_name = fields.Char('Statut', related='status_id.name')