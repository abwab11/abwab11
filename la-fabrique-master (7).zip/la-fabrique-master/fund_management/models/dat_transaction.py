from odoo import models, fields, api
from datetime import date

class FundManagementDatTransaction(models.Model):
    _name = 'fund_management.dat_transaction'
    _description = 'DAT Account Transaction'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'id desc'

    name = fields.Char(string='Code', copy=False, readonly=True, default=lambda self: self.env['ir.sequence'].next_by_code('fund.management.dat_transaction.sequence'))  # Auto-generated code
    transaction_name = fields.Char(string="Nom de la transaction", required=True)
    transaction_type = fields.Selection([('entry', 'Entrée'), 
                                         ('guarantee_call', 'Appel de garantie'), 
                                         ('interest', 'Intérêts')], 
                                        string="Type", required=True)
    amount = fields.Float(string="Montant", required=True)
    transaction_date = fields.Date(string="Date", default=fields.Date.context_today)
    state = fields.Selection([
        ('brouillon', 'Brouillon'),
        ('en_cours', 'En-cours'),
        ('valider', 'Valider'),
        ('annuler', 'Annuler')
    ], string='Statut', default='brouillon') 
    account_id = fields.Many2one('fund_management.dat_account', string="Compte DAT", required=True)
    beneficiary_id = fields.Many2one('fund_management.bank', string="Bénéficiaire", 
                                     help="Visible uniquement pour 'Appel de garantie'")
    dossier_id = fields.Many2one('fund_management.demand', string="Dossier", 
                                 help="Filtré en fonction du bénéficiaire")
    demand_ids = fields.One2many('fund_management.demand', related='beneficiary_id.demand_ids', string="Dossiers")
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)

    @api.constrains('dossier_id', 'beneficiary_id')
    def _check_amount(self):
        for record in self:
            if record.dossier_id and record.beneficiary_id:
                if record.amount > 0:
                    record.amount = -(record.amount)
        

    @api.onchange('transaction_type')
    def _onchange_transaction_type(self):
        if self.transaction_type != 'guarantee_call':
            self.beneficiary_id = False
            self.dossier_id = False

    # Buttons logic
    def action_soumettre(self):
        self.state = 'en_cours'
    
    def action_valider(self):
        self.state = 'valider'

    def action_annuler(self):
        self.state = 'annuler'