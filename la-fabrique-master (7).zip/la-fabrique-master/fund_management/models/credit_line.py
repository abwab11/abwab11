#-*- coding:utf-8 -*-
from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from datetime import date
from odoo.tools.misc import formatLang
from dateutil.relativedelta import relativedelta
import logging
from calendar import monthrange
_logger = logging.getLogger(__name__)
class CreditLines(models.Model):
    _name = 'fund_management.credit_line'
    _description = "Lignes de crédit"
    
    demand_id = fields.Many2one('fund_management.demand', string="Dossier", ondelete="cascade")
    dat_account_id = fields.Many2one('fund_management.dat_account', string="Compte DAT associé", related='demand_id.dat_account_id', store=True)
    mixte = fields.Boolean(string='Mixte ? ', related="demand_id.demand_type_id.mixte", store=True)
    name = fields.Char(string=u"Libellé", tracking=True)
    reference = fields.Char(string="Numéro de ligne", readonly=True, default=lambda self: self.env['ir.sequence'].next_by_code('fund.management.credit_line.sequence'))
    credit_type = fields.Many2one("fund_management.credit_type" ,string="Nature du crédit", tracking=True)
    loan_amount = fields.Float(string=u"Montant") # Capital en début de période
    loan_amount_euro = fields.Float(string=u"Montant de la ligne en Euro ", compute='_compute_loan_amount_euro', store=True) # Capital en début de période
    interest_rate = fields.Float(string=u"Intérêt mensuel TTC", digits=[12, 3])
    deferred_month = fields.Integer(string=u"Différé")
    # term_of_loan = fields.Integer(string=u"Echéance", compute="_compute_loan_term", store=True)
    garantee_percent = fields.Float(string=u"Quotité de garantie (en %)")
    total_interest = fields.Float(string=u"Cout du prêt", compute='_compute_total_interest', store=True)
    turnover_interest = fields.Float(string=u"% du CA à rembourser ")
    month_duration = fields.Integer(string=u"Durée", tracking=True)
    # beneficiary_ids = fields.Many2many("banking_accounts_commitment.beneficiary", related='guarantee_id.beneficiary_ids')
    # beneficiary_id = fields.Many2one("banking_accounts_commitment.beneficiary", string=u"Bénéficiaire", tracking=True, domain="[('id', 'in', beneficiary_ids)]")
    garantee_amount = fields.Float(string="Montant de la garantie", compute='_compute_garantee_amount', store=True)
    # beneficiary_name = fields.Char(related='beneficiary_id.name', string=u'Bénéficiaire', readonly=True)
    differed_in_month = fields.Float(string="Différé (mois)")
    commission_rate = fields.Float(string=u"Taux de commission", default=1)
    etablishment_date = fields.Date(string="Date de mise en place", tracking=True)
    first_installment_date = fields.Date(string="Date du 1er remboursement de capital", compute="_compute_first_installment_date", store=True)
    # months_between_each_due_date = fields.Integer(string="Mois entre chaque échéance", compute="_compute_months_between_each_due_date", store=True)
    # due_amount_per_year = fields.Float(string=u"Montant échéance annuel", compute="_compute_due_amount_per_year")
    type_of_installement = fields.Selection([("1", "Mensuel"), ("3", "Trimestriel"), ("6", "Semestriel"), ("12", "Annuel"), ("infinite",'In fine')],'Fréquence de remboursement')
    contribution_nature = fields.Selection([("natural", "En nature"), ("numeric", "En numéraire")], "Nature de l'apport personnel (15%)")
    personal_contribution = fields.Float("Montant de l'apport personnel", compute='_compute_personal_contribution', store=True)
    # installment_x_amount = fields.Float(string="Type de remboursement", compute="compute_installment_x_amount")
    duration_in_month = fields.Float(string="Durée de remboursement (mois)")
    is_intern_fund = fields.Boolean(string='Fonds interne?', related='demand_id.is_intern_fund', store=True) 
    is_intern_fund_mixte = fields.Boolean(string='Fonds interne?', related='demand_id.is_intern_fund_mixte', store=True) 
    # repayment_date = fields.Date(string="Date de remboursement", tracking=True)
    cash_flow_lines = fields.One2many('fund_management.cash_flow.line', 'credit_line_id', string="TOTAL CHIFFRE D'AFFAIRES")
    amortization_lines_ids = fields.One2many('fund_management.amortization.line', 'credit_line_id', string="Tableau d'amortissement")
    load_schedule_ids = fields.One2many('fund_management.payment.schedule', 'credit_line_id', string="Tableau d'amortissement")
    is_loan_schedule = fields.Boolean('Is loan schedule', compute='_compute_is_loan_schedule')
    is_amortization_lines_ids = fields.Boolean(string='Amortisseent?', compute='_compute_is_amortization_lines_ids') 
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)

    total_paid_amount = fields.Float(string="Montant total rembourser", compute='_compute_total_paid_amount', store=True)
    total_unpaid_count = fields.Float(string=u"Nombre d'impayé", compute='_compute_total_unpaid_count', store=True)
    total_unpaid_amount = fields.Float(string=u"Montant total impayé", compute='_compute_total_unpaid_amount', store=True)

    total_am_paid_amount = fields.Float(string="Montant total rembourser", compute='_compute_total_am_paid_amount', store=True)
    total_am_unpaid_count = fields.Float(string=u"Nombre d'impayé", compute='_compute_total_am_unpaid_count', store=True)
    total_am_unpaid_amount = fields.Float(string=u"Montant total impayé", compute='_compute_total_am_unpaid_amount', store=True)
    
    # Beneficiary
    financial_institution_id = fields.Many2one('fund_management.work_owner', string="Bénéficiaire", related='demand_id.financial_institution_id', store=True)
    ninea = fields.Char(string='NINEA/IFU', related='demand_id.financial_institution_id.ninea', store=True)
    capital = fields.Char(string='Capital', related='demand_id.financial_institution_id.capital', store=True)
    acronym = fields.Char(string='Abrégé', related='demand_id.financial_institution_id.acronym', store=True)
    business_sector_id = fields.Many2one("fund_management.business_sector", string=u"Secteur d'activité", related='demand_id.financial_institution_id.business_sector_id', store=True)
    rccm = fields.Char(string="RCCM", related='demand_id.financial_institution_id.rccm', store=True)
    legal_status = fields.Many2one("fund_management.legal_status" ,string="Forme juridique", related='demand_id.financial_institution_id.legal_status', store=True)
    faculty = fields.Many2one("fund_management.faculty" ,string=u"Filière", related='demand_id.financial_institution_id.faculty', store=True)
    manager_gender = fields.Selection([('male', "Homme"), ('female', "Femme")] ,string="Genre du dirigeant", related='demand_id.financial_institution_id.manager_gender', store=True)
    leader_last_name = fields.Char(string="Nom du dirigeant", related='demand_id.financial_institution_id.leader_last_name', store=True)
    leader_first_name = fields.Char(string="Prénom du dirigeant", related='demand_id.financial_institution_id.leader_first_name', store=True)
    born_date = fields.Date(string="Date de naissance", related='demand_id.financial_institution_id.born_date', store=True)
    age = fields.Integer(string="Age", related='demand_id.financial_institution_id.age', store=True)
    type_of_loan = fields.Selection([("variable", "Variable"), ("fix", "Fixe")],'Type de remboursement', default='variable')

    def test(self):
        lines = self.env['fund_management.credit_line'].sudo().search([])
        if lines:
            for line in lines:
                line._compute_loan_amount_euro()

    @api.depends('loan_amount')  
    def _compute_loan_amount_euro(self):
        euro = self.env['ir.config_parameter'].sudo().get_param('fund.euro')
        for record in self:
            if record.loan_amount:
                record.loan_amount_euro = record.loan_amount / float(euro)
            else:
                record.loan_amount = 0
      
    def format_amount(self, amount, currency="FCFA"):
            # Format the amount with spaces as thousands separator
        amount_str = f"{amount:,}".replace(",", " ")
        # Add the currency suffix
        return f"{amount_str} {currency}"   
    
    def format_date(self, date):
        return date.strftime('%d/%m/%Y')
  
    @api.depends('load_schedule_ids')  
    def _compute_is_loan_schedule(self):
        for record in self:
            if record.load_schedule_ids:
                record.is_loan_schedule = True
            else:
                record.is_loan_schedule = False
  
    @api.depends('amortization_lines_ids.refund_made')  
    def _compute_total_am_unpaid_count(self):
        for record in self:
            count = 0
            if record.amortization_lines_ids:
                for t in record.amortization_lines_ids:
                    if t.refund_made  == 'no':
                        count += 1
                record.total_am_unpaid_count = count
            else:
                record.total_am_unpaid_count = 0
  
    @api.depends('amortization_lines_ids.refund_made')  
    def _compute_total_am_unpaid_amount(self):
        for record in self:
            if record.amortization_lines_ids:
                record.total_am_unpaid_amount = sum((t.total_monthly_repayment) for t in record.amortization_lines_ids if t.refund_made == 'no')
            else:
                record.total_am_unpaid_amount = 0
                
    @api.depends('amortization_lines_ids.refund_made')  
    def _compute_total_am_paid_amount(self):
        for record in self:
            if record.amortization_lines_ids:
                record.total_am_paid_amount = sum((t.total_monthly_repayment) for t in record.amortization_lines_ids if t.refund_made == 'yes' )
            else:
                record.total_am_paid_amount = 0
  
    @api.depends('load_schedule_ids.state')  
    def _compute_total_unpaid_count(self):
        for record in self:
            count = 0
            if record.load_schedule_ids:
                for t in record.load_schedule_ids:
                    if t.state  == 'unpaid':
                        count += 1
                record.total_unpaid_count = count
            else:
                record.total_unpaid_count = 0
  
    @api.depends('load_schedule_ids.state')  
    def _compute_total_unpaid_amount(self):
        for record in self:
            if record.load_schedule_ids:
                record.total_unpaid_amount = sum((t.amount) for t in record.load_schedule_ids if t.state == 'unpaid')
            else:
                record.total_unpaid_amount = 0
                
    @api.depends('load_schedule_ids.state')  
    def _compute_total_paid_amount(self):
        for record in self:
            if record.load_schedule_ids:
                record.total_paid_amount = sum((t.amount) for t in record.load_schedule_ids if t.state in ('paid', 'late_payment') )
            else:
                record.total_paid_amount = 0

    @api.depends('amortization_lines_ids', 'amortization_lines_ids.interest_repaid')
    def _compute_total_interest(self):
        for fund in self:
            fund.total_interest = sum(t.interest_repaid for t in fund.amortization_lines_ids)
            


    @api.depends('etablishment_date', 'differed_in_month')
    def _compute_first_installment_date(self):
        for record in self:
            if record.etablishment_date:
                # Calculate the date after the differed months
                installment_date = record.etablishment_date + relativedelta(months=record.differed_in_month + 1)
                
                # Find the total number of days in the installment month
                days_in_month = monthrange(installment_date.year, installment_date.month)[1]
                
                # Set the first_installment_date to the last day of that month
                record.first_installment_date = installment_date.replace(day=days_in_month)
            else:
                # Reset the value if no etablishment_date is provided
                record.first_installment_date = False
    
    @api.depends('is_amortization_lines_ids')
    def _compute_is_amortization_lines_ids(self):
        for record in self:
            if record.amortization_lines_ids:
                record.is_amortization_lines_ids = True
            else:    
                record.is_amortization_lines_ids = True
                
                
    @api.depends('contribution_nature', 'loan_amount')
    def _compute_personal_contribution(self):
        for record in self:
            if record.contribution_nature == 'numeric':
                record.personal_contribution = round(record.loan_amount * 0.15)
            else:
                record.personal_contribution = 0.0
    
    @api.depends('loan_amount', 'garantee_percent')
    def _compute_garantee_amount(self):
        for record in self:
            if record.garantee_percent != 0:
                percent = record.garantee_percent / 100
                record.garantee_amount = round(record.loan_amount * percent)   
            else:
                record.garantee_amount = 0
    
    @api.depends('month_duration', 'first_installment_date', 'etablishment_date')
    def generate_cash_flow_lines(self):
        for record in self:
            if record.month_duration and record.etablishment_date:
                # Clear existing lines
                record.cash_flow_lines = [(5, 0, 0)]
                current_date = fields.Date.from_string(record.etablishment_date)

                for i in range(record.month_duration):
                    # For each month, generate a cash flow line
                    record.cash_flow_lines.create({
                        'credit_line_id': record.id,
                        'month': current_date.strftime("%b-%y")
                    })
                    current_date += relativedelta(months=1)

    @api.depends('month_duration', 'loan_amount', 'differed_in_month', 'etablishment_date', 'etablishment_date', 'type_of_installement')
    def generate_loan_schedule(self):
        amortization_ids = []
        for record in self:
            record.sudo().write({'is_intern_fund': True})
            if record.loan_amount <= 0 or record.month_duration <= 0:
                raise ValidationError(_("Le montant du crédit et la durée doivent être supérieurs à zéro."))
            
            record.load_schedule_ids.unlink()
            type_of_installement = int(record.type_of_installement)
            current_month = record.etablishment_date + relativedelta(months=1)
            if not current_month:
                raise ValidationError(_("Veuillez renseigner la date de mise en place."))
            
            differed_in_month = record.deferred_month
            amount = round(record.loan_amount / record.month_duration)
            cumul_payment = amount
            for i in range(0, record.month_duration):
                is_differed = True if differed_in_month > 1 else False
                new_amortization = record.env['fund_management.payment.schedule'].create({
                    'number': i + 1,
                    'repayment_date': current_month,
                    'credit_line_id': record.id,
                    'amount': amount,
                    'cumul_payment': cumul_payment,
                    'remaining_amount': record.loan_amount if is_differed else (record.loan_amount - cumul_payment),
                    'state': 'non_echu'
                    # 'is_differed': True if differed_in_month > 1 else False
                })
                amortization_ids.append(new_amortization)
                cumul_payment = cumul_payment + amount
                current_month = current_month + relativedelta(months=type_of_installement)
                differed_in_month = differed_in_month - 1
            # record.amortization_lines_ids = [(6, 0, [c.id for c in amortization_ids])]
            
    # @api.depends('first_installment_date', 'etablishment_date', 'month_duration', 'differed_in_month', 'loan_amount')               
    # def generate_amortization_schedule(self):
    #     """Generates the amortization schedule based on the credit line details."""
    #     # self.ensure_one()
    #     amortization_ids = []
    #     for record in self:
            
    #         # Validate input
    #         if record.loan_amount <= 0 or record.month_duration <= 0:
    #             raise ValidationError(_("Le montant du crédit et la durée doivent être supérieurs à zéro."))

    #         # Clear existing amortization lines
    #         record.amortization_lines_ids.unlink()
    #         current_month = record.etablishment_date
    #         if not current_month:
    #             raise ValidationError(_("Veuillez renseigner la date de mise en place."))
            
    #         differed_in_month = record.differed_in_month
    #         for i in range(0, record.month_duration):
    #             # Create amortization line
    #             new_amortization = record.env['fund_management.amortization.line'].create({
    #                 'installment_number': i + 1,
    #                 'month': current_month,
    #                 'credit_line_id': record.id,
    #                 'is_differed': True if differed_in_month >= 1 else False
    #             })
    #             amortization_ids.append(new_amortization)
    #             current_month = current_month + relativedelta(months=1)
    #             differed_in_month = differed_in_month - 1
    #         record.amortization_lines_ids = [(6, 0, [c.id for c in amortization_ids])]
                
    @api.depends('first_installment_date', 'etablishment_date', 'month_duration', 'differed_in_month', 'loan_amount')               
    def generate_amortization_schedule(self):
        """Generates the amortization schedule based on the credit line details."""
        amortization_ids = []
        for record in self:
            
            # Validate input
            if record.loan_amount <= 0 or record.month_duration <= 0:
                raise ValidationError(_("Le montant du crédit et la durée doivent être supérieurs à zéro."))

            # Clear existing amortization lines
            record.amortization_lines_ids.unlink()

            # Start with etablishment_date
            current_month = record.etablishment_date
            if not current_month:
                raise ValidationError(_("Veuillez renseigner la date de mise en place."))

            differed_in_month = record.differed_in_month
            for i in range(record.month_duration):
                # Determine the date for this installment
                if i == 0:
                    # First installment uses the etablishment_date
                    installment_date = current_month
                else:
                    # Other installments use the last day of the month
                    next_month = current_month + relativedelta(months=1)
                    last_day = monthrange(next_month.year, next_month.month)[1]
                    installment_date = next_month.replace(day=last_day)

                # Create amortization line
                new_amortization = record.env['fund_management.amortization.line'].create({
                    'installment_number': i + 1,
                    'month': installment_date,
                    'capital_due': record.loan_amount,
                    'credit_line_id': record.id,
                    'is_differed': True if differed_in_month >= 2 else False
                })
                amortization_ids.append(new_amortization)

                # Move to the next month for calculation
                current_month = installment_date
                differed_in_month -= 1
            
            # Assign the generated amortization lines
            record.amortization_lines_ids = [(6, 0, [c.id for c in amortization_ids])]


    def update_amortization(self):
        for record in self:
            loan_amount = record.loan_amount
            type_of_loan = record.type_of_loan
             
            if record.amortization_lines_ids:
                current_month = record.etablishment_date
                differed_in_months = [i for i in range(0, int(record.differed_in_month))]

                for line in record.amortization_lines_ids:
                    # Determine the date for this installment
                    if line.installment_number == 1:
                        # First installment uses the etablishment_date
                        installment_date = current_month
                    else:
                        # Other installments use the last day of the next month
                        next_month = current_month + relativedelta(months=1)
                        last_day = monthrange(next_month.year, next_month.month)[1]
                        installment_date = next_month.replace(day=last_day)

                    # Update the amortization line
                    c = (line.capital_repaid if type_of_loan != 'fix' else line.refund_amount)
                    line.write({
                        'capital_due': (loan_amount - c),
                        'month': installment_date,
                        'is_differed': True if line.installment_number in differed_in_months else False
                    })
                    _logger.debug('loan_amountloan_amountloan_amountloan_amountloan_amount %r --- %r ', line.capital_repaid,  line.capital_due)
                    if type_of_loan != 'fix':
                        # line._compute_early_repayment()
                        line._compute_repaid_amount()
                        line._compute_remain_to_be_paid()
                        line._compute_repayment_date()
                        line._compute_capital_repaid()
                        line._compute_monthly_interest()
                        line._compute_total_repayment()

                    # Prepare for the next iteration
                    current_month = installment_date
                    loan_amount -= line.capital_repaid
            else:
                # Regenerate the amortization schedule if no lines exist
                record.generate_amortization_schedule()
          
    # def update_amortization(self):
    #     for record in self:
    #         loan_amount = record.loan_amount
    #         if record.amortization_lines_ids:
    #             current_month = record.etablishment_date
    #             differed_in_month = [i for i in range(0, int(record.differed_in_month) + 1)]
    #             i = 1
                
    #             for line in record.amortization_lines_ids:
    #                 line.write({
    #                     'capital_due': loan_amount - line.capital_repaid,
    #                     'month': current_month,
    #                     'is_differed': True if line.installment_number in differed_in_month else False
    #                 })
    #                 i += 1
    #                 current_month = current_month + relativedelta(months=1)
    #                 loan_amount = loan_amount - line.capital_repaid
    #         else:
    #             record.generate_amortization_schedule()