# -*- coding: utf-8 -*-
from odoo import api, fields, models

class Sector(models.Model):
    _name = "fund_management.business_sector"
   
    name = fields.Char(string=u"Secteur d'activité", required=True)
    psp = fields.Char(string="Pôle Sectoriel Prioritaire (PSP)")
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)