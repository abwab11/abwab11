#-*- coding:utf-8 -*-
from odoo import models, fields, api, _

class WorkOwner(models.Model):
    _name = 'fund_management.work_owner'
    _inherits = {'res.partner' : 'partner_id'}
    _description = "Work owner"
    
    partner_id = fields.Many2one('res.partner', string='Partenaire', required=True, ondelete="cascade")
    partner_manager_ids = fields.One2many('fund_management.partner_manager', 'work_owner_id', string="Gestionnaires")
    portfolio_manager_user_ids = fields.One2many('res.users', 'work_owner_id', string='Manager')
