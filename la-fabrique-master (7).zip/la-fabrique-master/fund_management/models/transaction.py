#-*- coding:utf-8 -*-
from odoo import models, fields, api,  _
import logging
from odoo.exceptions import ValidationError

_logger = logging.getLogger(__name__)

class Transaction(models.Model):
    _name = 'fund_management.transaction'
    _description = 'Transactions Management'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'id desc'

    montant = fields.Float(string='Montant', required=True)  # Amount (can be positive or negative)
    beneficiaire_id = fields.Many2one('fund_management.work_owner', string='Bénéficiaire')  # Beneficiary
    dossier_id = fields.Many2one('fund_management.demand', string="Dossier", 
                                 help="Filtré en fonction du bénéficiaire")
    demand_ids = fields.One2many('fund_management.demand', related='beneficiaire_id.demand_ids', string="Dossiers")

    type_operation = fields.Selection([
        ('remboursement', 'Remboursement'),
        ('entree', 'Entrée'),
        ('transfert', 'Transfert'),
        ('decaissement', 'Décaissement')
    ], string='Types d’Opérations')  # Operation types
    fund_id = fields.Many2one('fund_management.funds', string='Fonds')  # Fund (shown when operation is transfer)
    loan_id = fields.Many2one('fund_management.payment.schedule', string='Amortissement')  # Fund (shown when operation is transfer)
    source_fund_id = fields.Many2one('fund_management.funds', string="Fond d'origin")  # Fund (shown when operation is transfer)
    bailleur_id = fields.Many2one('res.partner', string='Bailleurs')  # Bailleur (filtered when operation is 'Entrée') 
    bailleurs_ids = fields.Many2many('res.partner', string='Bailleurs', related="fund_id.bailleurs_ids")  # Partners (filtered to only show companies)
    date = fields.Date(string='Date', required=True, default=fields.Date.today())  # Date of transaction
    justificatif = fields.Binary(string='Justificatif')  # Justification file
    state = fields.Selection([
        ('brouillon', 'Brouillon'),
        ('en_cours', 'En-cours'),
        ('valider', 'Valider'),
        ('annuler', 'Annuler')
    ], string='Statut', default='brouillon')  # Status of transaction
    is_installment_transaction = fields.Boolean('Est un décaissement', compute='_compute_is_installment',store=True)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)
    remaining_disbursement = fields.Float('Remaining dissbursement', related='dossier_id.remaining_disbursement',store=True)
    remaining_disbursement_for_sub = fields.Float('Remaining dissbursement', related='dossier_id.remaining_disbursement_for_sub',store=True)
    is_credit = fields.Boolean(string='Credit ?', related='dossier_id.is_credit',store=True)
    is_subvention = fields.Boolean(string='Subvention ?', related='dossier_id.is_subvention',store=True)
    mixte = fields.Boolean(string='Mixte ?', related='dossier_id.mixte')

    def check_demand_amount(self):
        for record in self:
            if record.dossier_id:
                max_credit_amount = record.dossier_id.max_credit_amount
                transaction_ids = self.env['fund_management.transaction'].search([('dossier_id', '=' , record.dossier_id.id)])
                total_disbursed_amount_to_check = sum(-(t.montant) for t in record.dossier_id.transaction_ids if t.state == 'valider')
                if total_disbursed_amount_to_check > max_credit_amount:
                    raise ValidationError("La somme des décaissements ne peut pas excéder le montant total du crédit accordé.")

    @api.constrains('is_installment_transaction', 'montant')
    def check_transaction_amount(self):
        for record in self:
            if record.is_installment_transaction:
                if record.montant > 0:
                    record.montant = -(record.montant)
                record.type_operation = 'decaissement'
                record.beneficiaire_id = record.dossier_id.financial_institution_id
                record.fund_id = record.dossier_id.fund_id

    @api.depends('dossier_id')
    def _compute_is_installment(self):
        for record in self:
            if record.dossier_id:
                record.is_installment_transaction = True
                record._compute_installment_field()
            else:
                record.is_installment_transaction = False
                
    @api.depends('dossier_id')
    def _compute_installment_field(self):
        for record in self:
            if record.dossier_id:
                record.type_operation = 'decaissement'
                record.beneficiaire_id = record.dossier_id.financial_institution_id.id
                record.fund_id = record.dossier_id.fund_id.id

    # Buttons logic
    def action_soumettre(self):
        if self.is_credit and self.dossier_id.credit_amount > 0 and self.remaining_disbursement > 0 and self.remaining_disbursement < -(self.montant) or -(self.montant) > self.dossier_id.credit_amount > 0:
            raise ValidationError("La somme des décaissements ne peut pas excéder le montant total du crédit accordé.")
        if self.is_subvention and self.dossier_id.subvention_amount > 0 and self.remaining_disbursement_for_sub > 0  and self.remaining_disbursement_for_sub < -(self.montant) or -(self.montant) > self.dossier_id.subvention_amount > 0:
            raise ValidationError("La somme des décaissements ne peut pas excéder le montant total de la subvention accordée.")
        self.state = 'en_cours'
    
    def action_valider(self):
        if self.is_credit and self.dossier_id.credit_amount > 0 and self.remaining_disbursement > 0 and self.remaining_disbursement < -(self.montant) or -(self.montant) > self.dossier_id.credit_amount > 0:
            raise ValidationError("La somme des décaissements ne peut pas excéder le montant total du crédit accordé.")
        if self.is_subvention and self.dossier_id.subvention_amount > 0 and self.remaining_disbursement_for_sub > 0  and self.remaining_disbursement_for_sub < -(self.montant) or -(self.montant) > self.dossier_id.subvention_amount > 0 :
            raise ValidationError("La somme des décaissements ne peut pas excéder le montant total de la subvention accordée.")
        self.state = 'valider'

    def action_annuler(self):
        self.state = 'annuler'

