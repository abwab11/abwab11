#-*- coding:utf-8 -*-
from odoo import models, fields, api, _

class CreditType(models.Model):
    _name = 'fund_management.credit_type'
    _order = "name asc"
    _description = "Nature du crédit"
    
    name = fields.Char(string=u'Nature du crédit', required=True)
    company_id = fields.Many2one('res.company', string='Company', default=lambda self: self.env.company)