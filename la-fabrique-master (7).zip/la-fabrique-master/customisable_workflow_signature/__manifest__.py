# -*- coding: utf-8 -*-
{
    'name': 'Lims Workflow signature',
    'version': '17.0',
    'license': 'LGPL-3',
    'depends': [ 'base','customisable_workflow',
                #  'base_fontawesome'
    ],
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'views/res_users.xml',
        'views/step.xml',
        'wizard/upload_signed_doc_wizard.xml',
        'views/work_signed_document.xml',
        'views/workflow.xml'
    ],
    'demo': [],
    'qweb': [],
    'images': [],
    'installable': True,
    'application': False,
    'auto_install': False,
}
