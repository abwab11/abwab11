# -*- coding: utf-8 -*-
{
    'name': 'Lims validation',
    'license': 'LGPL-3',
    'depends': [ 'base','customisable_workflow',
                #  'base_fontawesome'
    ],
    'data': [
        'security/ir.model.access.csv',
        'security/security.xml',
        'views/step.xml',
        'views/work_document_to_validate.xml'
    ],
    'demo': [],
    'qweb': [],
    'images': [],
    'installable': True,
    'application': False,
    'auto_install': False,
}
