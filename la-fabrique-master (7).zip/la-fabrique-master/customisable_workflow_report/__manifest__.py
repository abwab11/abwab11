# -*- coding: utf-8 -*-
{
    'name': 'Lims workflow report',
    'version': '17.0',
    'license': 'LGPL-3',
    'depends': [
        'base', 
        'customisable_workflow',
        'customisable_workflow_signature',
        'customisable_workflow_validation'
    ],
    'data': [
        'security/ir.model.access.csv'
    ],
    'assets': {
        'web.assets_backend': [
            'customisable_workflow_report/static/src/components/**/*'
        ]
    },
    'demo': [],
    'qweb': [],
    'images': [],
    'installable': True,
    'application': False,
    'auto_install': False,
}
