// /** @odoo-module **/

import { Component } from "@odoo/owl";

export class GroupTitle extends Component {
};
GroupTitle.template = "customisable_workflow_report.GroupTitleWidget";
