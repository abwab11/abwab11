from odoo.tests.common import TransactionCase, tagged
from odoo import Command
from odoo.exceptions import ValidationError
import base64
import docx
import tempfile
import os
import logging
Logger = logging.getLogger(__name__)


@tagged('test_work_document')

class TestWork(TransactionCase):

    def setUp(self):
        super(TestWork, self).setUp()
        self.work_model = self.env['customisable_workflow.work_test']
        self.group_user = self.env.ref('base.group_user')
        self.document_model = self.env['customisable_workflow.document']
        self.work_given_document_model = self.env['customisable_workflow.work_given_document']
        self.step_model = self.env['customisable_workflow.step']
        self.workflow_model = self.env['customisable_workflow.workflow']
        self.group_manager = self.env.ref('base.group_system')
        self.step_decision_model = self.env['customisable_workflow.step_decision']
        self.user_model = self.env['res.users']

        # String to encode
        encoded_data = "dGVzdCBmaWxlIGNvbnRlbnRz"
        self.decoded_data = base64.b64decode(encoded_data.encode('utf-8'))

        # Create a document
        temp_docx_path = self._create_temporary_docx_file()
        f =  open(temp_docx_path, 'rb')
        doc = f.read()
        f.close()

        self.document_4 = self.document_model.create({
            'name': 'Document 4',
            'source': 'generated',
            'document': base64.b64encode(doc),
            'document_format_to_generate': 'docx',
            'is_required': True,
        })

        # Create Workflow without step
        self.workflow = self.workflow_model.create({
            'name': 'Processus demo',
        })

        # Create Steps
        self.workflow_step1 = self.step_model.create({
            'name': 'Etape 1',
            'workflow_id': self.workflow.id,
            'allowed_group_ids': [(6, 0, [self.group_manager.id]),(6, 0, [self.group_user.id])],
        })

        # Set start_step_id for workflow
        self.workflow.write({
            'start_step_id': self.workflow_step1.id
        }) 

        # Create a work 
        self.work = self.work_model.create({
            'name': 'Test Work',
            'workflow_id': self.workflow.id,
        })

        self.user_test = self.user_model.create({
            'name': 'Test User',
            'login': 'testuser',
            'groups_id': [(6, 0, [self.group_manager.id])]
        })

        self.user1 = self.user_model.create({
            'name': 'User 1',
            'login': 'user1',
            'groups_id': [(6, 0, [self.group_user.id])]
        })
        # User env
        self.test_user_env = self.env(user=self.user_test)
        self.user1_env = self.env(user=self.user1)


    # Test that checks if the required documents have been created.Raises an exception if the required documents have not been created.
    def test_check_given_document_ids_exist(self):
        # Arrange
        workflow_decision_step1_step2 = self._create_decision_for_step1_to_step2()
        # Act
        self.work.with_env(self.test_user_env).with_context(decision_id = workflow_decision_step1_step2.id).make_a_decision()
        #Assert
        self.assertIsNotNone(self.work.given_document_ids, "L'utilisateur doit voir les documents à fournir sur l'étape.")

    #Tests that a ValidationError is raised if a required document is missing for the previous step before going to the next step.
    def test_missing_required_document(self):
        # Arrange
        workflow_decision_step1_step2 = self._create_decision_for_step1_to_step2()
        workflow_decision_step2_to_step3 = self._create_decision_for_step2_to_step3()
        # Act
        self.work.with_env(self.test_user_env).with_context(decision_id = workflow_decision_step1_step2.id).make_a_decision()
        self.work.given_document_ids[0].write({
            'attachment': self.decoded_data
        })
        self.work.invalidate_recordset()
        #Assert
        with self.assertRaises(ValidationError, msg="L'utilisateur doit être informé quand il ne fournit pas un document obligatoire."):
            self.work.with_env(self.test_user_env).with_context(decision_id = workflow_decision_step2_to_step3.id).make_a_decision()
   
    #Tests that no error is raised if a required document is already provided for the previous step before going to the next step.
    def test_existing_required_document(self):
        # Arrange
        workflow_decision_step1_step2 = self._create_decision_for_step1_to_step2()
        workflow_decision_step2_to_step3 = self._create_decision_for_step2_to_step3()
        # Act
        self.work.with_env(self.test_user_env).with_context(decision_id = workflow_decision_step1_step2.id).make_a_decision()
        self.work.given_document_ids.write({
            'attachment': self.decoded_data
        })
        self.work.invalidate_recordset()
        self.work.with_env(self.test_user_env).with_context(decision_id = workflow_decision_step2_to_step3.id).make_a_decision()
        #Assert
        self.assertEqual(self.work.current_step_id.name, 'Etape 3', "On passe à l'étape suivante avec succès après avoir fourni le document requis à l'étape précédente.")

    # Test that checks if the documents to genered have been created.
    def test_check_genered_document_exist(self):
        # Arrange
        workflow_decision_step1_to_step4 = self._create_decision_for_step1_to_step4()
        # Act
        self.work.with_env(self.test_user_env).with_context(decision_id = workflow_decision_step1_to_step4.id).make_a_decision()
        #Assert
        self.assertIsNotNone(self.work.given_document_ids, "L'utilisateur doit voir les documents à générer sur l'étape.")

    def test_docs_to_validate(self):
        # Arrange
        workflow_decision_step1_to_step4 = self._create_decision_for_step1_to_step4()
        workflow_decision_step4_to_step5 = self._create_decision_for_step4_to_step5()
        # Act
        self.work.with_env(self.test_user_env).with_context(decision_id = workflow_decision_step1_to_step4.id).make_a_decision()
        self.work.with_env(self.test_user_env).with_context(decision_id = workflow_decision_step4_to_step5.id).make_a_decision()
        # Assert
        self.assertIsNotNone(self.work.document_to_validate_ids, "L'utilisateur doit voir les documents à valider sur l'étape.")
        for document_to_validate in self.work.document_to_validate_ids:
            document_to_validate.validate()
            self.assertEqual(document_to_validate.state, 'validated', "Le document doit être validé")

    def test_docs_to_reject(self):
        # Arrange
        workflow_decision_step1_to_step4 = self._create_decision_for_step1_to_step4()
        workflow_decision_step4_to_step5 = self._create_decision_for_step4_to_step5()
        # Act
        self.work.with_env(self.test_user_env).with_context(decision_id = workflow_decision_step1_to_step4.id).make_a_decision()
        self.work.with_env(self.test_user_env).with_context(decision_id = workflow_decision_step4_to_step5.id).make_a_decision()
        # Assert
        self.assertIsNotNone(self.work.document_to_validate_ids, "L'utilisateur doit voir les documents à valider sur l'étape.")
        for document_to_validate in self.work.document_to_validate_ids:
            document_to_validate.reject()
            self.assertEqual(document_to_validate.state, 'rejected', "Le document est rejeté")

    def test_not_authorized_user_cannot_validate(self):
        # Arrange
        workflow_decision_step1_to_step4 = self._create_decision_for_step1_to_step4()
        workflow_decision_step4_to_step5 = self._create_decision_for_step4_to_step5()
        # Act
        self.work.with_env(self.user1_env).with_context(decision_id = workflow_decision_step1_to_step4.id).make_a_decision()
        self.work.with_env(self.user1_env).with_context(decision_id = workflow_decision_step4_to_step5.id).make_a_decision()
        # Assert
        document_to_validate = self.work.document_event_ids.filtered(lambda x: x.type == 'validation')
        self.assertFalse(document_to_validate.with_env(self.user1_env).current_user_can_act, "Un utilisateur non autorisé ne doit pas pouvoir valider")

    def test_authorized_user_can_validate(self):
        # Arrange
        workflow_decision_step1_to_step4 = self._create_decision_for_step1_to_step4()
        workflow_decision_step4_to_step5 = self._create_decision_for_step4_to_step5()
        # Act
        self.work.with_env(self.test_user_env).with_context(decision_id = workflow_decision_step1_to_step4.id).make_a_decision()
        self.work.with_env(self.test_user_env).with_context(decision_id = workflow_decision_step4_to_step5.id).make_a_decision()
        # Assert
        document_to_validate = self.work.document_event_ids.filtered(lambda x: x.type == 'validation')
        self.assertTrue(document_to_validate.with_env(self.test_user_env).current_user_can_act, "Un utilisateur autorisé doit pouvoir valider les documents.")


    # Function to Create a new .docx document using the python-docx library
    def _create_temporary_docx_file(self):
        doc = docx.Document()
        doc.add_heading('Titre du document', 0)
        doc.add_paragraph('Ceci est un fichier temporaire généré avec Python.')
        # Créer un fichier temporaire
        with tempfile.NamedTemporaryFile(suffix=".docx", delete=False) as tmp_file:
            # Sauvegarder le document dans le fichier temporaire
            doc.save(tmp_file.name)
        return tmp_file.name

    # Create step with given document
    def _create_step_with_given_document(self):
        # Create a provided document
        self.document_2 = self.document_model.create({
            'name': 'Document 2',
            'source': 'provided',
            'is_required': True
        })
        self.document_3 = self.document_model.create({
            'name': 'Document 3',
            'source': 'provided',
            'is_required': True
        })
        # Create Steps
        self.workflow_step2 = self.step_model.create({
            'name': 'Etape 2',
            'workflow_id': self.workflow.id,
            'allowed_group_ids': [(6, 0, [self.group_manager.id])],
            'provided_document_ids': [(4, self.document_2.id), (4, self.document_3.id)]
        })
        return self.workflow_step2

    #Create decision to step1 to step2
    def _create_decision_for_step1_to_step2(self):
        # Create Step Decisions
        self.workflow_decision_step1_step2 = self.step_decision_model.create({
            'name': 'Valider',
            'workflow_id': self.workflow.id,
            'step_id': self.workflow_step1.id,
            'target_step_id': self._create_step_with_given_document().id,
        })
        return self.workflow_decision_step1_step2

    # Create decision to pass step2 to step3
    def _create_decision_for_step2_to_step3(self):
        # Create Step 3
        self.workflow_step3 = self.step_model.create({
            'name': 'Etape 3',
            'workflow_id': self.workflow.id,
            'allowed_group_ids': [(6, 0, [self.group_manager.id])],
        })
        # Create Step Decisions
        self.workflow_decision_step2_to_step3 = self.step_decision_model.create({
            'name': 'Soumettre',
            'workflow_id': self.workflow.id,
            'step_id': self._create_step_with_given_document().id,
            'target_step_id': self.workflow_step3.id,
        })
        return self.workflow_decision_step2_to_step3


    # Create decision to step1 to step4
    def _create_decision_for_step1_to_step4(self):
        # Create Step 4
        self.workflow_step4 = self.step_model.create({
            'name': 'Etape 4',
            'workflow_id': self.workflow.id,
            'allowed_group_ids': [(6, 0, [self.group_manager.id]), (6, 0, [self.group_user.id])],
            'generated_document_ids': [(4, self.document_4.id)]
        })
        # Create Step Decisions
        self.workflow_decision_step1_to_step4 = self.step_decision_model.create({
            'name': 'Passer à étape 4',
            'workflow_id': self.workflow.id,
            'step_id': self.workflow_step1.id,
            'target_step_id': self.workflow_step4.id,
        })
        return self.workflow_decision_step1_to_step4

    # Create decision to step4 to step5
    def _create_decision_for_step4_to_step5(self):
        # Create Step 5
        self.workflow_step5 = self.step_model.create({
            'name': 'Etape 5',
            'workflow_id': self.workflow.id,
            'allowed_group_ids': [(6, 0, {self.group_manager.id})],
            'document_to_validate_ids': [(0, 0, {'document_id': self.document_4.id,
                                                'allowed_group_ids': [(6, 0, [self.group_manager.id])]})]
        })
        # Create Step Decisions
        self.workflow_decision_step4_to_step5 = self.step_decision_model.create({
            'name': 'Passer à étape 5',
            'workflow_id': self.workflow.id,
            'step_id': self.workflow_step4.id,
            'target_step_id': self.workflow_step5.id,
        })
        return self.workflow_decision_step4_to_step5